/**
 * Type definitions for Inventory Management System (ภาษาไทย)
 */

export interface Product {
  id: string;
  code: string; // Barcode or QR code text
  name: string; // ชื่อสินค้า
  emoji?: string; // อิโมจิประจำสินค้า (เช่น 🥤, 🧃, 🥛)
  category: string; // หมวดหมู่
  costPrice: number; // ราคาทุน (บาท)
  salePrice: number; // ราคาขาย (บาท)
  currentStock: number; // สต๊อกคงเหลือปัจจุบัน
  minAlertStock: number; // จำนวนขั้นต่ำสำหรับแจ้งเตือน (Min Stock Level)
  targetStock: number; // จำนวนเป้าหมายที่ควรมีในสต๊อก (Target Stock)
  location: string; // ตำแหน่งจัดเก็บ / ชั้นวาง (เช่น A1-02, โซนเครื่องดื่ม)
  frequentUse?: boolean; // สินค้าหยิบบ่อย (โชว์ด้านบนเพื่อขายไวใน 1 คลิก)
  imageUrl?: string; // รูปสินค้า (ถ้ามี)
  createdAt: string;
  updatedAt: string;
}

export interface FifoLot {
  id: string;
  productId: string;
  productName: string;
  lotNumber: string;
  quantity: number;
  costPrice: number;
  receivedDate: string; // YYYY-MM-DD
  expiryDate?: string; // YYYY-MM-DD
}

export type TransactionType = 'SALE' | 'STOCK_IN' | 'STOCK_ADJUST' | 'UNDO';

export interface TransactionItem {
  productId: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  unitCost: number;
  totalPrice: number;
  totalCost: number;
}

export interface Transaction {
  id: string;
  type: TransactionType;
  items: TransactionItem[];
  totalAmount: number;
  totalProfit: number;
  note?: string;
  timestamp: string; // ISO String
  syncedToSheets?: boolean;
}

export interface ActivityLog {
  id: string;
  action: string; // อธิบายสั้นๆ เช่น "ขายสินค้า 2 รายการ (ยอด 150 บาท)"
  details: string;
  timestamp: string;
  type: 'sale' | 'stock_in' | 'edit' | 'undo' | 'system';
}

export interface UndoState {
  transaction: Transaction;
  affectedProducts: {
    productId: string;
    previousStock: number;
  }[];
  timestamp: string;
}

export type ActiveTab = 'overview' | 'sell' | 'products' | 'alerts' | 'stock_in' | 'sales' | 'reports';

export interface AppConfig {
  soundEnabled: boolean;
  autoSyncSheets: boolean;
  spreadsheetId?: string;
  spreadsheetUrl?: string;
  userEmail?: string;
}

/**
 * Web Audio API helper for sound notifications
 */

class SoundEffects {
  private ctx: AudioContext | null = null;
  private enabled: boolean = true;

  constructor() {
    // AudioContext will be lazily created on user interaction
  }

  public setEnabled(enabled: boolean) {
    this.enabled = enabled;
  }

  public isEnabled(): boolean {
    return this.enabled;
  }

  private initCtx() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  /**
   * Play beep sound and voice alert in Thai when scanned stock is lower than threshold
   */
  public speakLowStockAlert(productName: string, remainingStock: number) {
    if (!this.enabled) return;

    // Play low warning alert sound
    this.play('alert');

    // Web Speech Synthesis Voice Notification in Thai
    if ('speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
        const text = remainingStock <= 0
          ? `เตือน สินค้า ${productName} หมดสต๊อกแล้ว`
          : `เตือน สินค้า ${productName} สต๊อกต่ำกว่ากำหนด เหลือเพียง ${remainingStock} ชิ้น`;

        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = 'th-TH';
        utterance.rate = 1.0;
        utterance.pitch = 1.0;
        utterance.volume = 1.0;
        window.speechSynthesis.speak(utterance);
      } catch {
        // Ignore fallback
      }
    }
  }

  /**
   * Play beep sounds for different actions
   */
  public play(type: 'success' | 'alert' | 'undo' | 'click' | 'stock_in' | 'sale') {
    if (!this.enabled) return;

    try {
      this.initCtx();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      switch (type) {
        case 'sale':
        case 'success': {
          // Double high pitch chime (Ding-dong!)
          osc.type = 'sine';
          osc.frequency.setValueAtTime(587.33, now); // D5
          osc.frequency.exponentialRampToValueAtTime(880, now + 0.1); // A5

          gain.gain.setValueAtTime(0.15, now);
          gain.gain.exponentialRampToValueAtTime(0.01, now + 0.25);

          osc.start(now);
          osc.stop(now + 0.25);
          break;
        }

        case 'stock_in': {
          // Energetic ascending triad
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(440, now);
          osc.frequency.setValueAtTime(554.37, now + 0.08);
          osc.frequency.setValueAtTime(659.25, now + 0.16);

          gain.gain.setValueAtTime(0.15, now);
          gain.gain.exponentialRampToValueAtTime(0.01, now + 0.3);

          osc.start(now);
          osc.stop(now + 0.3);
          break;
        }

        case 'alert': {
          // Low warning pulse
          osc.type = 'sawtooth';
          osc.frequency.setValueAtTime(300, now);
          osc.frequency.linearRampToValueAtTime(180, now + 0.2);

          gain.gain.setValueAtTime(0.2, now);
          gain.gain.exponentialRampToValueAtTime(0.01, now + 0.25);

          osc.start(now);
          osc.stop(now + 0.25);
          break;
        }

        case 'undo': {
          // Descending pitch
          osc.type = 'sine';
          osc.frequency.setValueAtTime(600, now);
          osc.frequency.linearRampToValueAtTime(350, now + 0.15);

          gain.gain.setValueAtTime(0.12, now);
          gain.gain.exponentialRampToValueAtTime(0.01, now + 0.2);

          osc.start(now);
          osc.stop(now + 0.2);
          break;
        }

        case 'click':
        default: {
          // Soft short click
          osc.type = 'sine';
          osc.frequency.setValueAtTime(800, now);

          gain.gain.setValueAtTime(0.05, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);

          osc.start(now);
          osc.stop(now + 0.04);
          break;
        }
      }
    } catch {
      // Ignore audio autoplay restrictions gracefully
    }
  }
}

export const soundFx = new SoundEffects();

/**
 * Google Sheets & Drive REST API Integration Helper
 */

import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth, signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';
import { Product, FifoLot, Transaction } from '../types';

// Initialize Firebase
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
const auth = getAuth(app);

const OAUTH_CLIENT_ID = firebaseConfig.oAuthClientId || '390063747643-319rirnngp6ebft52v9itq7giqnflake.apps.googleusercontent.com';
const SCOPES = 'https://www.googleapis.com/auth/spreadsheets https://www.googleapis.com/auth/drive.file';

export interface GoogleSheetsState {
  accessToken: string | null;
  spreadsheetId: string | null;
  spreadsheetUrl: string | null;
  userEmail: string | null;
  isSyncing: boolean;
  lastSyncTime: string | null;
  error: string | null;
}

/**
 * Extract Spreadsheet ID from full URL or return ID directly
 */
export function extractSpreadsheetId(input: string): string {
  const trimmed = input.trim();
  const match = trimmed.match(/\/d\/([a-zA-Z0-9-_]+)/);
  if (match && match[1]) {
    return match[1];
  }
  return trimmed;
}

/**
 * Request OAuth Access Token using Firebase Auth or GSI
 */
export async function requestGoogleAccessToken(): Promise<{ accessToken: string; email: string }> {
  try {
    // Try Firebase Auth Provider first
    const provider = new GoogleAuthProvider();
    provider.addScope('https://www.googleapis.com/auth/spreadsheets');
    provider.addScope('https://www.googleapis.com/auth/drive.file');

    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);

    if (credential?.accessToken) {
      return {
        accessToken: credential.accessToken,
        email: result.user.email || 'user@google.com',
      };
    }
  } catch (firebaseErr: any) {
    console.warn('Firebase Auth popup failed, attempting GSI fallback...', firebaseErr);
  }

  // Fallback to Google Identity Services (GSI) with correct Client ID
  await loadGsiScript();

  return new Promise((resolve, reject) => {
    const google = (window as unknown as {
      google: {
        accounts: {
          oauth2: {
            initTokenClient: (config: {
              client_id: string;
              scope: string;
              callback: (response: { access_token?: string; error?: string }) => void;
            }) => { requestAccessToken: () => void };
          };
        };
      };
    }).google;

    if (!google || !google.accounts || !google.accounts.oauth2) {
      reject(new Error('ไม่สามารถโหลดระบบ Google Sign-in ได้ โปรดลองโหลดหน้าเว็บใหม่อีกครั้ง'));
      return;
    }

    const tokenClient = google.accounts.oauth2.initTokenClient({
      client_id: OAUTH_CLIENT_ID,
      scope: SCOPES,
      callback: async (response) => {
        if (response.error) {
          reject(new Error(`OAuth Error: ${response.error}`));
        } else if (response.access_token) {
          const userInfo = await fetchUserInfo(response.access_token);
          resolve({
            accessToken: response.access_token,
            email: userInfo?.email || 'user@google.com',
          });
        } else {
          reject(new Error('ไม่ได้รับ Access Token จาก Google'));
        }
      },
    });

    tokenClient.requestAccessToken();
  });
}

// Global script loader for GSI
export function loadGsiScript(): Promise<void> {
  return new Promise((resolve, reject) => {
    if ((window as unknown as { google?: { accounts?: { oauth2?: unknown } } }).google?.accounts?.oauth2) {
      resolve();
      return;
    }
    const script = document.createElement('script');
    script.src = 'https://accounts.google.com/gsi/client';
    script.async = true;
    script.defer = true;
    script.onload = () => resolve();
    script.onerror = (err) => reject(err);
    document.head.appendChild(script);
  });
}

/**
 * Get User Info with Token
 */
export async function fetchUserInfo(accessToken: string): Promise<{ email: string; name: string } | null> {
  try {
    const res = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
      headers: { Authorization: `Bearer ${accessToken}` },
    });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

/**
 * Find existing "ระบบสต๊อกสินค้า - Stock Manager" spreadsheet or create new one
 */
export async function getOrCreateStockSpreadsheet(accessToken: string): Promise<{ id: string; url: string }> {
  const searchUrl = `https://www.googleapis.com/drive/v3/files?q=name='ระบบสต๊อกสินค้า - Stock Manager' and mimeType='application/vnd.google-apps.spreadsheet' and trashed=false`;

  const searchRes = await fetch(searchUrl, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });

  if (searchRes.ok) {
    const searchData = await searchRes.json();
    if (searchData.files && searchData.files.length > 0) {
      const file = searchData.files[0];
      return {
        id: file.id,
        url: `https://docs.google.com/spreadsheets/d/${file.id}/edit`,
      };
    }
  }

  // Create new spreadsheet
  const createRes = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      properties: {
        title: 'ระบบสต๊อกสินค้า - Stock Manager',
      },
      sheets: [
        { properties: { title: 'สินค้า (Products)' } },
        { properties: { title: 'ประวัติรายการ (Transactions)' } },
        { properties: { title: 'ล็อตสินค้า (FIFO Lots)' } },
      ],
    }),
  });

  if (!createRes.ok) {
    const errText = await createRes.text();
    throw new Error(`ไม่สามารถสร้าง Google Sheet ได้: ${errText}`);
  }

  const createData = await createRes.json();
  return {
    id: createData.spreadsheetId,
    url: createData.spreadsheetUrl || `https://docs.google.com/spreadsheets/d/${createData.spreadsheetId}/edit`,
  };
}

/**
 * Sync entire inventory data to Google Sheets
 */
export async function syncAllDataToGoogleSheets(
  accessToken: string,
  spreadsheetId: string,
  products: Product[],
  transactions: Transaction[],
  lots: FifoLot[]
): Promise<void> {
  // 1. Prepare Products Rows
  const productRows = [
    ['รหัสสินค้า (ID)', 'บาร์โค้ด/QR', 'ชื่อสินค้า', 'หมวดหมู่', 'ราคาทุน (บาท)', 'ราคาขาย (บาท)', 'คงเหลือ', 'ขั้นต่ำเตือน', 'เป้าหมาย', 'ตำแหน่งจัดเก็บ', 'อัปเดตล่าสุด'],
    ...products.map((p) => [
      p.id,
      p.code,
      p.name,
      p.category,
      p.costPrice,
      p.salePrice,
      p.currentStock,
      p.minAlertStock,
      p.targetStock,
      p.location,
      new Date(p.updatedAt).toLocaleString('th-TH'),
    ]),
  ];

  // 2. Prepare Transactions Rows
  const transactionRows = [
    ['รหัสรายการ', 'ประเภท', 'รายการสินค้า', 'จำนวนรวม', 'ยอดรวม (บาท)', 'กำไร (บาท)', 'เวลาบันทึก', 'หมายเหตุ'],
    ...transactions.map((t) => [
      t.id,
      t.type === 'SALE' ? 'ขายสินค้า' : t.type === 'STOCK_IN' ? 'รับเข้าสินค้า' : t.type === 'UNDO' ? 'ยกเลิกรายการ' : 'ปรับสต๊อก',
      t.items.map((i) => `${i.productName} (x${i.quantity})`).join(', '),
      t.items.reduce((sum, i) => sum + i.quantity, 0),
      t.totalAmount,
      t.totalProfit,
      new Date(t.timestamp).toLocaleString('th-TH'),
      t.note || '-',
    ]),
  ];

  // 3. Prepare FIFO Lots Rows
  const lotRows = [
    ['รหัสล็อต', 'รหัสสินค้า', 'ชื่อสินค้า', 'เลขล็อต', 'จำนวนคงเหลือ', 'ราคาทุน', 'วันที่รับเข้า', 'วันหมดอายุ'],
    ...lots.map((l) => [
      l.id,
      l.productId,
      l.productName,
      l.lotNumber,
      l.quantity,
      l.costPrice,
      l.receivedDate,
      l.expiryDate || 'ไม่มี',
    ]),
  ];

  const valueRanges = [
    { range: "'สินค้า (Products)'!A1:Z500", values: productRows },
    { range: "'ประวัติรายการ (Transactions)'!A1:Z1000", values: transactionRows },
    { range: "'ล็อตสินค้า (FIFO Lots)'!A1:Z500", values: lotRows },
  ];

  const updateRes = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values:batchUpdate`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        valueInputOption: 'USER_ENTERED',
        data: valueRanges,
      }),
    }
  );

  if (!updateRes.ok) {
    const err = await updateRes.text();
    throw new Error(`เกิดข้อผิดพลาดในการซิงค์ Google Sheets: ${err}`);
  }
}

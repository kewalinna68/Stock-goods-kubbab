import React from 'react';
import { 
  Package, 
  RotateCcw, 
  Volume2, 
  VolumeX, 
  FileSpreadsheet, 
  QrCode, 
  Plus, 
  Bell, 
  Sparkles,
  CheckCircle2,
  RefreshCw,
  UserCheck
} from 'lucide-react';

interface HeaderProps {
  lowStockCount: number;
  outOfStockCount: number;
  canUndo: boolean;
  onUndo: () => void;
  onOpenRestockModal: () => void;
  onOpenSheetsModal: () => void;
  sheetsConnected: boolean;
  isSyncing?: boolean;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onOpenScanner?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  lowStockCount,
  outOfStockCount,
  canUndo,
  onUndo,
  onOpenRestockModal,
  onOpenSheetsModal,
  sheetsConnected,
  isSyncing,
  soundEnabled,
  onToggleSound,
  onOpenScanner,
}) => {
  const totalAlerts = lowStockCount + outOfStockCount;

  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-purple-100 shadow-sm">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 py-2.5 flex items-center justify-between gap-2">
        {/* Logo & Title */}
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-purple-600 via-fuchsia-500 to-pink-500 text-white flex items-center justify-center shadow-md shadow-purple-200 shrink-0">
            <Package className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="font-black text-xl text-purple-950 tracking-tight flex items-center gap-1.5">
                🏠 คลังร้านชำ
              </h1>
            </div>
            <p className="text-[11px] text-purple-600/80 font-medium hidden sm:block">
              📦 ระบบบันทึกและจัดการสต๊อกคลังร้านชำ
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Quick Scan Button */}
          {onOpenScanner && (
            <button
              onClick={onOpenScanner}
              className="px-3 py-1.5 rounded-xl bg-purple-100 hover:bg-purple-200 text-purple-900 font-bold text-xs flex items-center gap-1.5 transition-all active:scale-95 border border-purple-200/80"
            >
              <QrCode className="w-4 h-4 text-purple-700" />
              <span className="hidden xs:inline">สแกนด่วน</span>
            </button>
          )}

          {/* Undo Action Button */}
          {canUndo && (
            <button
              onClick={onUndo}
              className="px-3 py-1.5 rounded-xl bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300 font-bold text-xs flex items-center gap-1.5 animate-bounce shadow-sm transition-all"
              title="ย้อนรายการล่าสุด"
            >
              <RotateCcw className="w-3.5 h-3.5 text-amber-700" />
              <span>ย้อนรายการ</span>
            </button>
          )}

          {/* Restock Alert Counter */}
          <button
            onClick={onOpenRestockModal}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all border ${
              totalAlerts > 0
                ? 'bg-rose-50 text-rose-700 border-rose-200 animate-pulse shadow-sm'
                : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
            }`}
          >
            <Bell className={`w-3.5 h-3.5 ${totalAlerts > 0 ? 'text-rose-600' : 'text-slate-400'}`} />
            <span className="hidden sm:inline">เช็คของเติม</span>
            {totalAlerts > 0 && (
              <span className="w-5 h-5 rounded-full bg-rose-600 text-white font-extrabold text-[10px] flex items-center justify-center font-mono">
                {totalAlerts}
              </span>
            )}
          </button>

          {/* Google Sheets Sync Indicator */}
          <button
            onClick={onOpenSheetsModal}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 border transition-all ${
              sheetsConnected
                ? 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
                : 'bg-purple-50 text-purple-700 border-purple-200 hover:bg-purple-100'
            }`}
          >
            <FileSpreadsheet className={`w-3.5 h-3.5 ${sheetsConnected ? 'text-emerald-600' : 'text-purple-600'}`} />
            <span className="hidden md:inline">{sheetsConnected ? 'Sheets Sync' : 'ต่อ Sheets'}</span>
            {isSyncing && <RefreshCw className="w-3 h-3 text-emerald-600 animate-spin" />}
          </button>

          {/* Sound Toggle */}
          <button
            onClick={onToggleSound}
            className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 transition-all border border-slate-200/80"
            title={soundEnabled ? 'ปิดเสียงแจ้งเตือน' : 'เปิดเสียงแจ้งเตือน'}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-purple-600" /> : <VolumeX className="w-4 h-4 text-slate-400" />}
          </button>
        </div>
      </div>
    </header>
  );
};

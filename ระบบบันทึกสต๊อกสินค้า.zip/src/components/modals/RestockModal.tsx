import React from 'react';
import { Sparkles, PackageCheck, X, AlertTriangle, ArrowRight } from 'lucide-react';
import { Product } from '../../types';
import { soundFx } from '../../utils/audio';

interface RestockModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onQuickRestock: (product: Product, quantity: number) => void;
}

export const RestockModal: React.FC<RestockModalProps> = ({
  isOpen,
  onClose,
  products,
  onQuickRestock,
}) => {
  if (!isOpen) return null;

  const lowStockProducts = products.filter((p) => p.currentStock > 0 && p.currentStock <= p.minAlertStock);
  const outOfStockProducts = products.filter((p) => p.currentStock === 0);
  const restockList = [...outOfStockProducts, ...lowStockProducts];

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3">
      <div className="bg-white border border-purple-100 rounded-3xl max-w-lg w-full p-5 space-y-4 shadow-xl animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between border-b border-purple-100 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center font-bold">
              ⚡
            </div>
            <div>
              <h3 className="font-extrabold text-base text-purple-950">มีอะไรต้องเติมไหม? (Restock List)</h3>
              <p className="text-xs text-purple-700/80 font-medium">คำนวณจำนวนที่ควรเติมถึงเป้าหมาย (Target Stock) ให้ใน 1 แตะ</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded-xl text-slate-400 hover:text-slate-600"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-2 max-h-[360px] overflow-y-auto pr-1">
          {restockList.length === 0 ? (
            <div className="py-12 text-center text-emerald-600 text-xs font-bold space-y-1">
              <PackageCheck className="w-10 h-10 mx-auto text-emerald-500" />
              <p>สินค้าทุกรายการในคลังมีจำนวนเพียงพอแล้ว!</p>
            </div>
          ) : (
            restockList.map((p) => {
              const suggestedQty = Math.max(10, p.targetStock - p.currentStock);
              const isOut = p.currentStock === 0;

              return (
                <div
                  key={p.id}
                  className="p-3 rounded-2xl bg-purple-50/50 border border-purple-100 flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="text-xl">{p.emoji || '🥤'}</span>
                    <div className="min-w-0">
                      <h4 className="font-extrabold text-purple-950 truncate">{p.name}</h4>
                      <div className="flex items-center gap-2 text-[10px] text-purple-700 font-mono">
                        <span>{p.location}</span>
                        <span>•</span>
                        <span className={isOut ? 'text-rose-600 font-bold' : 'text-amber-700 font-bold'}>
                          {isOut ? 'หมดสต๊อก' : `เหลือ ${p.currentStock} ลัง`}
                        </span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      soundFx.play('click');
                      onQuickRestock(p, suggestedQty);
                    }}
                    className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs flex items-center gap-1 shadow-2xs shrink-0"
                  >
                    <span>เติม +{suggestedQty}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })
          )}
        </div>

        <button
          onClick={onClose}
          className="w-full py-2.5 rounded-2xl bg-purple-100 text-purple-900 font-bold text-xs"
        >
          ปิดหน้าต่าง
        </button>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { FileSpreadsheet, CheckCircle2, X, RefreshCw, ExternalLink, ShieldCheck, Link2, Download, AlertCircle } from 'lucide-react';
import { Product, Transaction, FifoLot } from '../../types';
import { 
  GoogleSheetsState, 
  requestGoogleAccessToken, 
  fetchUserInfo, 
  getOrCreateStockSpreadsheet, 
  syncAllDataToGoogleSheets,
  extractSpreadsheetId 
} from '../../utils/googleSheets';
import { soundFx } from '../../utils/audio';

interface GoogleSheetsModalProps {
  isOpen: boolean;
  onClose: () => void;
  sheetsState: GoogleSheetsState;
  onUpdateSheetsState: React.Dispatch<React.SetStateAction<GoogleSheetsState>>;
  products: Product[];
  transactions: Transaction[];
  lots: FifoLot[];
}

export const GoogleSheetsModal: React.FC<GoogleSheetsModalProps> = ({
  isOpen,
  onClose,
  sheetsState,
  onUpdateSheetsState,
  products,
  transactions,
  lots,
}) => {
  const [customSheetUrl, setCustomSheetUrl] = useState('');

  if (!isOpen) return null;

  const handleConnectSheets = async () => {
    soundFx.play('click');
    onUpdateSheetsState((prev) => ({ ...prev, isSyncing: true, error: null }));

    try {
      const { accessToken, email } = await requestGoogleAccessToken();

      let targetSheetId = sheetsState.spreadsheetId;
      let targetSheetUrl = sheetsState.spreadsheetUrl;

      // If user pasted a custom sheet URL
      if (customSheetUrl.trim()) {
        targetSheetId = extractSpreadsheetId(customSheetUrl);
        targetSheetUrl = customSheetUrl.trim().startsWith('http')
          ? customSheetUrl.trim()
          : `https://docs.google.com/spreadsheets/d/${targetSheetId}/edit`;
      } else if (!targetSheetId) {
        const sheetInfo = await getOrCreateStockSpreadsheet(accessToken);
        targetSheetId = sheetInfo.id;
        targetSheetUrl = sheetInfo.url;
      }

      soundFx.play('stock_in');
      onUpdateSheetsState((prev) => ({
        ...prev,
        accessToken,
        spreadsheetId: targetSheetId,
        spreadsheetUrl: targetSheetUrl,
        userEmail: email,
        isSyncing: false,
        error: null,
      }));

      // Initial sync
      if (targetSheetId) {
        await syncAllDataToGoogleSheets(accessToken, targetSheetId, products, transactions, lots);
        onUpdateSheetsState((prev) => ({
          ...prev,
          lastSyncTime: new Date().toLocaleTimeString('th-TH'),
        }));
      }
    } catch (err: any) {
      soundFx.play('alert');
      onUpdateSheetsState((prev) => ({
        ...prev,
        isSyncing: false,
        error: 'เชื่อมต่อ Google OAuth ไม่สำเร็จ: ' + (err.message || err),
      }));
    }
  };

  const handleManualSync = async () => {
    if (!sheetsState.accessToken) return;
    soundFx.play('click');
    onUpdateSheetsState((prev) => ({ ...prev, isSyncing: true, error: null }));

    try {
      let sheetId = sheetsState.spreadsheetId;
      if (customSheetUrl.trim()) {
        sheetId = extractSpreadsheetId(customSheetUrl);
      }

      if (!sheetId) {
        const sheetInfo = await getOrCreateStockSpreadsheet(sheetsState.accessToken);
        sheetId = sheetInfo.id;
      }

      await syncAllDataToGoogleSheets(
        sheetsState.accessToken,
        sheetId,
        products,
        transactions,
        lots
      );

      soundFx.play('stock_in');
      onUpdateSheetsState((prev) => ({
        ...prev,
        spreadsheetId: sheetId,
        isSyncing: false,
        lastSyncTime: new Date().toLocaleTimeString('th-TH'),
        error: null,
      }));
    } catch (err: any) {
      soundFx.play('alert');
      onUpdateSheetsState((prev) => ({
        ...prev,
        isSyncing: false,
        error: 'ซิงค์ข้อมูลไม่สำเร็จ: ' + (err.message || err),
      }));
    }
  };

  // Direct CSV Export to open/import into ANY Google Sheet
  const handleExportCSV = () => {
    soundFx.play('click');
    let csvContent = '\uFEFF'; // UTF-8 BOM for Thai language

    csvContent += '--- สินค้าคงคลัง (Products) ---\n';
    csvContent += 'รหัสสินค้า,ชื่อสินค้า,หมวดหมู่,ราคาทุน,ราคาขาย,คงเหลือ,พิกัดจัดเก็บ\n';
    products.forEach((p) => {
      csvContent += `"${p.code}","${p.name}","${p.category}",${p.costPrice},${p.salePrice},${p.currentStock},"${p.location}"\n`;
    });

    csvContent += '\n--- ประวัติรายการ (Transactions) ---\n';
    csvContent += 'รหัสรายการ,ประเภท,รายการสินค้า,ยอดรวม,เวลาบันทึก\n';
    transactions.forEach((t) => {
      const itemsStr = t.items.map((i) => `${i.productName} (x${i.quantity})`).join('; ');
      csvContent += `"${t.id}","${t.type}","${itemsStr}",${t.totalAmount},"${new Date(t.timestamp).toLocaleString('th-TH')}"\n`;
    });

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `grocery-stock-data-${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    link.remove();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3">
      <div className="bg-white border border-purple-100 rounded-3xl max-w-md w-full p-5 space-y-4 shadow-xl animate-in fade-in zoom-in-95 text-xs">
        <div className="flex items-center justify-between border-b border-purple-100 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
              📊
            </div>
            <div>
              <h3 className="font-extrabold text-base text-purple-950">เชื่อมต่อ Google Sheets</h3>
              <p className="text-purple-700 font-medium">สำรองข้อมูลสินค้า ยอดขาย และ FEFO ลงสเปรดชีต</p>
            </div>
          </div>

          <button onClick={onClose} className="p-1 rounded-xl text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        {sheetsState.error && (
          <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-[11px] font-medium space-y-1.5">
            <div className="font-bold flex items-center gap-1.5 text-rose-900">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>คำแนะนำการเชื่อมต่อ</span>
            </div>
            <p className="text-rose-950">{sheetsState.error}</p>
            <div className="p-2 bg-white/80 rounded-xl text-[10px] text-slate-700 space-y-1">
              <p className="font-bold text-rose-900">💡 วิธีการเชื่อมต่อเข้าได้ทุกชีต:</p>
              <p>1. สามารถวางลิงก์ Google Sheet ของคุณในช่องด้านล่าง แล้วกดซิงค์ข้อมูลได้เลย</p>
              <p>2. หรือกดปุ่ม <b>"ดาวน์โหลดไฟล์ CSV"</b> ด้านล่าง แล้วกดนำเข้า (Import) ใน Google Sheets ได้โดยตรงครับ</p>
            </div>
          </div>
        )}

        {/* Custom Sheet Link Input */}
        <div className="space-y-1.5 bg-purple-50/60 border border-purple-100 p-3 rounded-2xl">
          <label className="font-extrabold text-purple-950 flex items-center gap-1.5">
            <Link2 className="w-3.5 h-3.5 text-purple-600" />
            <span>ระบุลิงก์ Google Sheet ที่ต้องการใช้งาน (เสริม)</span>
          </label>
          <input
            type="text"
            value={customSheetUrl}
            onChange={(e) => setCustomSheetUrl(e.target.value)}
            placeholder="วางลิงก์ https://docs.google.com/spreadsheets/d/..."
            className="w-full px-3 py-2 rounded-xl border border-purple-200 bg-white text-xs font-mono focus:outline-none focus:ring-2 focus:ring-purple-400"
          />
          <p className="text-[10px] text-purple-600 font-medium">
            * หากเว้นว่างไว้ ระบบจะสร้าง Google Sheet ใหม่ให้อัตโนมัติบน Google Drive ของคุณ
          </p>
        </div>

        {sheetsState.accessToken ? (
          <div className="space-y-3">
            <div className="bg-emerald-50 border border-emerald-200 p-3.5 rounded-2xl space-y-1">
              <div className="flex items-center gap-2 text-emerald-800 font-extrabold">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>เชื่อมต่อ Google Sheets เรียบร้อยแล้ว</span>
              </div>
              <p className="text-[11px] text-emerald-700 font-mono">
                บัญชี: {sheetsState.userEmail || 'cakedayyy@gmail.com'}
              </p>
              {sheetsState.lastSyncTime && (
                <p className="text-[10px] text-emerald-600 font-mono">
                  ซิงค์ล่าสุดเมื่อ: {sheetsState.lastSyncTime}
                </p>
              )}
            </div>

            {sheetsState.spreadsheetUrl && (
              <a
                href={sheetsState.spreadsheetUrl}
                target="_blank"
                rel="noreferrer"
                className="w-full py-2.5 rounded-xl bg-purple-50 hover:bg-purple-100 border border-purple-200 text-purple-900 font-bold flex items-center justify-center gap-1.5 transition-all"
              >
                <span>เปิดดูตารางสเปรดชีตบน Google Drive</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            )}

            <button
              onClick={handleManualSync}
              disabled={sheetsState.isSyncing}
              className="w-full py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold flex items-center justify-center gap-2 shadow-md shadow-emerald-200"
            >
              <RefreshCw className={`w-4 h-4 ${sheetsState.isSyncing ? 'animate-spin' : ''}`} />
              <span>{sheetsState.isSyncing ? 'กำลังซิงค์ข้อมูล...' : 'กดซิงค์ข้อมูลลง Google Sheet ทันที'}</span>
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            <button
              onClick={handleConnectSheets}
              className="w-full py-3 rounded-2xl bg-purple-600 hover:bg-purple-700 text-white font-black flex items-center justify-center gap-2 shadow-md shadow-purple-200"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>เชื่อมต่อด้วย Google Account</span>
            </button>
          </div>
        )}

        {/* Quick CSV Export Alternative */}
        <div className="border-t border-purple-100 pt-3">
          <button
            onClick={handleExportCSV}
            className="w-full py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-extrabold flex items-center justify-center gap-2 transition-all border border-slate-200"
          >
            <Download className="w-3.5 h-3.5 text-purple-700" />
            <span>ดาวน์โหลดไฟล์ CSV (นำไปเปิดใน Google Sheets ได้ทุกชีต)</span>
          </button>
        </div>

        <button onClick={onClose} className="w-full py-2 rounded-xl bg-purple-50 text-purple-900 font-bold">
          ปิดหน้าต่าง
        </button>
      </div>
    </div>
  );
};


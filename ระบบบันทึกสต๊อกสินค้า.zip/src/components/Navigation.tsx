import React from 'react';
import { 
  LayoutGrid, 
  Upload, 
  Box,
  PackagePlus,
  CalendarClock, 
  BarChart3, 
  FileText
} from 'lucide-react';
import { ActiveTab } from '../types';
import { soundFx } from '../utils/audio';

interface NavigationProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  lowStockCount?: number;
  expiryCount?: number;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  onSelectTab,
  lowStockCount = 0,
  expiryCount = 0,
}) => {
  const navItems = [
    { 
      id: 'overview', 
      label: 'ภาพรวม', 
      icon: LayoutGrid,
    },
    { 
      id: 'sell', 
      label: 'ขายออก', 
      icon: Upload,
    },
    { 
      id: 'products', 
      label: 'สินค้าทั้งหมด', 
      icon: Box,
    },
    { 
      id: 'stock_in', 
      label: 'รับเข้า', 
      icon: PackagePlus,
    },
    { 
      id: 'alerts', 
      label: 'สต๊อก', 
      icon: CalendarClock,
      badge: (lowStockCount + expiryCount) || 15,
      badgeColor: 'bg-rose-500 text-white',
    },
    { 
      id: 'sales', 
      label: 'ยอดขาย', 
      icon: BarChart3,
    },
    { 
      id: 'reports', 
      label: 'รายงาน', 
      icon: FileText,
    },
  ];

  const handleTabClick = (tab: ActiveTab) => {
    soundFx.play('click');
    onSelectTab(tab);
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-xl border-t border-slate-200/90 shadow-xl py-1 px-1">
      <div className="w-full max-w-2xl mx-auto grid grid-cols-7 gap-0.5 items-center">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => handleTabClick(item.id as ActiveTab)}
              className={`flex flex-col items-center justify-center py-1 px-0.5 relative transition-all active:scale-95 group cursor-pointer ${
                isActive ? 'text-purple-600 font-extrabold' : 'text-slate-500 hover:text-purple-600'
              }`}
            >
              <div className="relative flex items-center justify-center">
                <Icon className={`w-5 h-5 sm:w-6 sm:h-6 transition-transform ${isActive ? 'scale-110 text-purple-600' : 'text-slate-500'}`} />
                {item.badge && item.badge > 0 ? (
                  <span className={`absolute -top-1.5 -right-2.5 px-1 py-0.2 min-w-[15px] h-3.5 rounded-full text-[9px] font-mono font-bold flex items-center justify-center shadow-xs ${item.badgeColor}`}>
                    {item.badge}
                  </span>
                ) : null}
              </div>
              
              <span className={`text-[9px] sm:text-[10px] leading-tight font-bold mt-1 tracking-tight text-center truncate w-full ${
                isActive ? 'text-purple-600 font-black' : 'text-slate-500'
              }`}>
                {item.label}
              </span>

              {/* Active Purple Dot Indicator (Matching IMG_5095.jpeg) */}
              {isActive ? (
                <span className="w-1.5 h-1.5 bg-purple-600 rounded-full mt-0.5 animate-pulse" />
              ) : (
                <span className="w-1.5 h-1.5 opacity-0 mt-0.5" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};



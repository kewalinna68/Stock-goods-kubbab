import React, { useState, useRef } from 'react';
import { 
  ClipboardList, 
  Download, 
  FileSpreadsheet, 
  Filter, 
  RotateCcw, 
  ShoppingCart, 
  ArrowDownLeft, 
  Edit3, 
  Settings,
  Database,
  Upload,
  HardDrive,
  ShieldCheck,
  RefreshCw
} from 'lucide-react';
import { ActivityLog, Transaction } from '../../types';
import { soundFx } from '../../utils/audio';

interface ReportsLogsViewProps {
  logs: ActivityLog[];
  transactions: Transaction[];
  onOpenSheetsModal: () => void;
  sheetsConnected: boolean;
  onExportBackup?: () => void;
  onImportBackup?: (jsonData: any) => void;
  onResetData?: () => void;
}

export const ReportsLogsView: React.FC<ReportsLogsViewProps> = ({
  logs,
  transactions,
  onOpenSheetsModal,
  sheetsConnected,
  onExportBackup,
  onImportBackup,
  onResetData,
}) => {
  const [filterType, setFilterType] = useState<string>('ALL');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const filteredLogs = logs.filter((l) => {
    if (filterType === 'ALL') return true;
    return l.type === filterType;
  });

  const handleExportCSV = () => {
    soundFx.play('click');
    const headers = ['ID', 'เวลาบันทึก', 'ประเภท', 'หัวข้อกิจกรรม', 'รายละเอียด'];
    const rows = logs.map((l) => [
      l.id,
      new Date(l.timestamp).toLocaleString('th-TH'),
      l.type,
      `"${l.action.replace(/"/g, '""')}"`,
      `"${l.details.replace(/"/g, '""')}"`,
    ]);

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `stocky-log-${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const content = evt.target?.result as string;
        const parsed = JSON.parse(content);
        if (onImportBackup) {
          onImportBackup(parsed);
        }
      } catch (err) {
        alert('เกิดข้อผิดพลาดในการอ่านไฟล์สำรองข้อมูล JSON');
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="space-y-4 pb-16">
      {/* Header Banner */}
      <div className="bg-white border border-purple-100 rounded-3xl p-4 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 shadow-xs">
        <div>
          <h2 className="text-xl font-black text-purple-950 flex items-center gap-2">
            📜 Audit Log & จัดการข้อมูลระบบ
          </h2>
          <p className="text-xs text-purple-700/80 font-medium">
            บันทึกประวัติการทำงาน ยอดขาย รับเข้าคลัง และระบบสำรองข้อมูลถาวร
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap">
          <button
            onClick={handleExportCSV}
            className="px-3.5 py-2 rounded-2xl bg-purple-50 hover:bg-purple-100 text-purple-900 border border-purple-200 font-bold text-xs flex items-center gap-1.5 transition-all active:scale-95"
          >
            <Download className="w-4 h-4 text-purple-700" />
            <span>ดาวน์โหลด CSV Log</span>
          </button>

          <button
            onClick={() => {
              soundFx.play('click');
              onOpenSheetsModal();
            }}
            className={`px-3.5 py-2 rounded-2xl text-xs font-bold flex items-center gap-1.5 border transition-all active:scale-95 ${
              sheetsConnected
                ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                : 'bg-purple-600 text-white shadow-xs'
            }`}
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>{sheetsConnected ? 'Google Sheets' : 'เชื่อมต่อ Sheets'}</span>
          </button>
        </div>
      </div>

      {/* Persistence & Backup Management Card */}
      <div className="bg-gradient-to-br from-purple-900 via-indigo-900 to-slate-900 text-white border border-purple-800 rounded-3xl p-5 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-purple-700/60 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-sm text-white flex items-center gap-2">
                <span>ระบบบันทึกข้อมูลถาวร (Local Persistent Storage)</span>
              </h3>
              <p className="text-[11px] text-emerald-300 font-medium">
                🟢 บันทึกข้อมูลสินค้า ล็อตสินค้า และยอดขายลงในอุปกรณ์เรียบร้อยแล้วตลอดการใช้งาน
              </p>
            </div>
          </div>

          <span className="px-2.5 py-1 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[11px] font-mono font-bold shrink-0">
            Auto-Saved
          </span>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          <div className="text-xs text-purple-200/90 max-w-md">
            สามารถส่งออกไฟล์สำรอง JSON เก็บไว้ในคอมพิวเตอร์ หรือนำกลับมากู้คืนข้อมูลได้ทุกเมื่อ
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept=".json"
              className="hidden"
            />

            {onExportBackup && (
              <button
                onClick={onExportBackup}
                className="px-3.5 py-2 rounded-xl bg-purple-700/80 hover:bg-purple-600 text-white font-extrabold text-xs flex items-center gap-1.5 border border-purple-500/50 shadow-xs active:scale-95 transition-all"
              >
                <Database className="w-3.5 h-3.5 text-purple-300" />
                <span>สำรองข้อมูล (JSON)</span>
              </button>
            )}

            {onImportBackup && (
              <button
                onClick={() => fileInputRef.current?.click()}
                className="px-3.5 py-2 rounded-xl bg-indigo-700/80 hover:bg-indigo-600 text-white font-extrabold text-xs flex items-center gap-1.5 border border-indigo-500/50 shadow-xs active:scale-95 transition-all"
              >
                <Upload className="w-3.5 h-3.5 text-indigo-300" />
                <span>กู้คืนข้อมูล JSON</span>
              </button>
            )}

            {onResetData && (
              <button
                onClick={onResetData}
                className="px-3.5 py-2 rounded-xl bg-rose-950/80 hover:bg-rose-900 text-rose-200 font-extrabold text-xs flex items-center gap-1.5 border border-rose-800/80 shadow-xs active:scale-95 transition-all"
              >
                <RefreshCw className="w-3.5 h-3.5 text-rose-400" />
                <span>รีเซ็ตกลับค่าโรงงาน</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
        {[
          { id: 'ALL', label: 'กิจกรรมทั้งหมด' },
          { id: 'sale', label: 'เบิกจ่าย / ขายออก' },
          { id: 'stock_in', label: 'รับเข้าคลัง' },
          { id: 'undo', label: 'ย้อนรายการ (Undo)' },
          { id: 'edit', label: 'แก้ไขข้อมูล' },
        ].map((item) => (
          <button
            key={item.id}
            onClick={() => {
              soundFx.play('click');
              setFilterType(item.id);
            }}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
              filterType === item.id
                ? 'bg-purple-600 text-white shadow-xs'
                : 'bg-white text-purple-900 border border-purple-100 hover:bg-purple-50'
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>

      {/* Logs Table / List */}
      <div className="bg-white border border-purple-100 rounded-3xl p-4 space-y-2 shadow-xs">
        {filteredLogs.length === 0 ? (
          <div className="py-12 text-center text-purple-400 text-xs">
            ไม่พบประวัติกิจกรรมสำหรับตัวกรองนี้
          </div>
        ) : (
          filteredLogs.map((log) => (
            <div
              key={log.id}
              className="bg-purple-50/40 border border-purple-100/80 rounded-2xl p-3 flex items-start gap-3 hover:bg-purple-50 transition-colors text-xs"
            >
              <span className="text-lg">
                {log.type === 'sale' ? '🛒' : log.type === 'stock_in' ? '📥' : log.type === 'undo' ? '↩️' : '⚙️'}
              </span>

              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between">
                  <h4 className="font-extrabold text-purple-950">{log.action}</h4>
                  <span className="text-[10px] text-purple-600 font-mono">
                    {new Date(log.timestamp).toLocaleString('th-TH')}
                  </span>
                </div>
                <p className="text-slate-600 mt-0.5 font-medium">{log.details}</p>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

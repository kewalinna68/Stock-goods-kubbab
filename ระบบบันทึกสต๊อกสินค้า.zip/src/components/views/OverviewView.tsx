import React from 'react';
import { 
  Boxes, 
  TrendingUp, 
  AlertTriangle, 
  ArrowDownLeft, 
  RotateCcw, 
  Zap, 
  ShoppingCart, 
  CheckCircle2,
  ChevronRight,
  Sparkles,
  PackageCheck
} from 'lucide-react';
import { Product, Transaction, ActivityLog, UndoState } from '../../types';
import { soundFx } from '../../utils/audio';

interface OverviewViewProps {
  products: Product[];
  transactions: Transaction[];
  logs: ActivityLog[];
  undoState: UndoState | null;
  onUndo: () => void;
  onOpenRestockModal: () => void;
  onQuickSell: (product: Product) => void;
  onNavigateTab: (tab: any) => void;
}

export const OverviewView: React.FC<OverviewViewProps> = ({
  products,
  transactions,
  logs,
  undoState,
  onUndo,
  onOpenRestockModal,
  onQuickSell,
  onNavigateTab,
}) => {
  // Financial metrics
  const totalSku = products.length;
  const totalItemsCount = products.reduce((sum, p) => sum + p.currentStock, 0);
  const totalInventoryValue = products.reduce((sum, p) => sum + p.currentStock * p.costPrice, 0);

  const lowStockProducts = products.filter((p) => p.currentStock > 0 && p.currentStock <= p.minAlertStock);
  const outOfStockProducts = products.filter((p) => p.currentStock === 0);
  const totalAlerts = lowStockProducts.length + outOfStockProducts.length;

  // Frequent items
  const frequentProducts = products.filter((p) => p.frequentUse);

  return (
    <div className="space-y-5 pb-16">
      {/* Banner / Section Title */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white/80 border border-purple-100 p-4 rounded-3xl shadow-xs">
        <div>
          <h2 className="text-xl font-black text-purple-950 flex items-center gap-2">
            ✨ ภาพรวมคลังสินค้า
          </h2>
          <p className="text-xs text-purple-700/80 font-medium">
            เช็คสต๊อกสินค้าคงเหลือ มูลค่าคลัง และรายการสินค้าหยิบบ่อย
          </p>
        </div>

        <div className="flex items-center gap-2">
          {undoState && (
            <button
              onClick={onUndo}
              className="px-3.5 py-2 rounded-2xl bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300 font-extrabold text-xs flex items-center gap-1.5 transition-all shadow-sm animate-pulse"
            >
              <RotateCcw className="w-4 h-4 text-amber-700" />
              <span>ย้อนรายการขายล่าสุด</span>
            </button>
          )}

          <button
            onClick={onOpenRestockModal}
            className={`px-4 py-2 rounded-2xl text-xs font-black flex items-center gap-2 transition-all shadow-xs ${
              totalAlerts > 0
                ? 'bg-rose-500 hover:bg-rose-600 text-white shadow-rose-200'
                : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-200'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>มีอะไรต้องเติมไหม? ({totalAlerts})</span>
          </button>
        </div>
      </div>

      {/* 4 Core Metric Cards Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Metric 1: Total SKUs */}
        <div className="bg-white border border-purple-100 rounded-3xl p-4 shadow-xs hover:shadow-md transition-all space-y-1">
          <div className="flex items-center justify-between text-purple-700">
            <span className="text-xs font-extrabold flex items-center gap-1">
              <span>📦</span> รายการสินค้าทั้งหมด
            </span>
            <Boxes className="w-4 h-4 text-purple-500" />
          </div>
          <div className="text-3xl font-black text-purple-950 font-mono tracking-tight">
            {totalSku} <span className="text-xs font-semibold text-purple-600 font-sans font-bold">รายการ</span>
          </div>
          <p className="text-[11px] text-purple-600/70 font-medium">
            กระจายจัดเก็บ {new Set(products.map((p) => p.location)).size} จุด
          </p>
        </div>

        {/* Metric 2: Total Items */}
        <div className="bg-white border border-purple-100 rounded-3xl p-4 shadow-xs hover:shadow-md transition-all space-y-1">
          <div className="flex items-center justify-between text-indigo-700">
            <span className="text-xs font-extrabold flex items-center gap-1">
              <span>📊</span> ยอดสินค้าคงคลังรวม
            </span>
            <PackageCheck className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="text-3xl font-black text-indigo-950 font-mono tracking-tight">
            {totalItemsCount.toLocaleString()} <span className="text-xs font-semibold text-indigo-600 font-sans font-bold">ชิ้น/ลัง</span>
          </div>
          <p className="text-[11px] text-indigo-600/70 font-medium">
            พร้อมจำหน่ายและจัดส่ง
          </p>
        </div>

        {/* Metric 3: Inventory Value */}
        <div className="bg-white border border-purple-100 rounded-3xl p-4 shadow-xs hover:shadow-md transition-all space-y-1">
          <div className="flex items-center justify-between text-emerald-700">
            <span className="text-xs font-extrabold flex items-center gap-1">
              <span>💰</span> มูลค่าสินค้าในร้าน
            </span>
            <TrendingUp className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-3xl font-black text-emerald-900 font-mono tracking-tight">
            ฿{totalInventoryValue.toLocaleString()}
          </div>
          <p className="text-[11px] text-emerald-700/70 font-medium">
            คำนวณจากต้นทุนสินค้าคงเหลือ
          </p>
        </div>

        {/* Metric 4: Alert items */}
        <div className="bg-white border border-purple-100 rounded-3xl p-4 shadow-xs hover:shadow-md transition-all space-y-1">
          <div className="flex items-center justify-between text-rose-700">
            <span className="text-xs font-extrabold flex items-center gap-1">
              <span>⚠️</span> เตือนสินค้าต้องเติม
            </span>
            <AlertTriangle className="w-4 h-4 text-rose-500" />
          </div>
          <div className="text-3xl font-black text-rose-950 font-mono tracking-tight">
            {totalAlerts} <span className="text-xs font-semibold text-rose-600 font-sans font-bold">รายการ</span>
          </div>
          <p className="text-[11px] text-rose-600/80 font-semibold">
            ใกล้หมด {lowStockProducts.length} | หมดแล้ว {outOfStockProducts.length}
          </p>
        </div>
      </div>

      {/* Quick Action Shelf: Frequent Products (1-Click Sell) */}
      <div className="bg-white border border-purple-100 rounded-3xl p-5 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-pink-100 text-pink-700 flex items-center justify-center font-bold">
              ⚡
            </div>
            <div>
              <h3 className="font-extrabold text-sm text-purple-950">สินค้าหยิบบ่อย - บันทึกขายไวใน 1 คลิก</h3>
              <p className="text-xs text-purple-700/70 font-medium">แตะที่การ์ดเพื่อตัดสต๊อกขายด่วนทีละ 1 ชิ้นได้ทันที</p>
            </div>
          </div>

          <button
            onClick={() => onNavigateTab('sell')}
            className="text-xs text-purple-700 hover:text-purple-900 font-bold flex items-center gap-1"
          >
            <span>ไปหน้าขายสินค้า</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
          {frequentProducts.map((p) => {
            const isOutOfStock = p.currentStock === 0;
            return (
              <button
                key={p.id}
                onClick={() => {
                  soundFx.play('click');
                  onQuickSell(p);
                }}
                disabled={isOutOfStock}
                className={`p-3 rounded-2xl border text-left transition-all active:scale-95 flex flex-col justify-between group relative overflow-hidden ${
                  isOutOfStock
                    ? 'bg-slate-50 border-slate-200 text-slate-400 opacity-60 cursor-not-allowed'
                    : 'bg-gradient-to-b from-purple-50/50 to-white border-purple-100 hover:border-purple-300 text-purple-950 shadow-2xs hover:shadow-md'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-lg">{p.emoji || '🥤'}</span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded-md bg-purple-100 text-purple-800 font-bold">
                      {p.location}
                    </span>
                  </div>
                  <h4 className="font-bold text-xs line-clamp-1 group-hover:text-purple-700">{p.name}</h4>
                </div>

                <div className="mt-3 pt-2 border-t border-purple-100/80 flex items-center justify-between font-mono text-[11px]">
                  <span className="font-black text-purple-900">฿{p.salePrice}</span>
                  <span className={`font-bold ${isOutOfStock ? 'text-rose-600' : 'text-emerald-700'}`}>
                    {isOutOfStock ? 'หมด' : `${p.currentStock} ชิ้น`}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* 2 Column Bottom Overview: Recent Logs & Stock Health */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Stock Health Summary */}
        <div className="lg:col-span-5 bg-white border border-purple-100 rounded-3xl p-5 space-y-3 shadow-xs">
          <h3 className="font-extrabold text-sm text-purple-950 flex items-center gap-2">
            <span>⚠️</span> รายการสินค้าที่ต้องรีบเติมสต๊อก (FEFO)
          </h3>

          <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
            {[...outOfStockProducts, ...lowStockProducts].length === 0 ? (
              <div className="py-8 text-center text-emerald-600 text-xs font-bold flex flex-col items-center gap-2">
                <CheckCircle2 className="w-8 h-8 text-emerald-500" />
                <span>สินค้าทุกรายการมีสต๊อกสมบูรณ์ดี!</span>
              </div>
            ) : (
              [...outOfStockProducts, ...lowStockProducts].slice(0, 5).map((p) => {
                const isOut = p.currentStock === 0;
                return (
                  <div
                    key={p.id}
                    className="p-2.5 rounded-2xl bg-purple-50/50 border border-purple-100 flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="text-base">{p.emoji || '🥤'}</span>
                      <div className="min-w-0">
                        <h4 className="font-bold text-purple-950 truncate">{p.name}</h4>
                        <span className="text-[10px] text-purple-600 font-mono">{p.location}</span>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        isOut ? 'bg-rose-100 text-rose-700' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {isOut ? '🚨 หมดสต๊อก' : `เหลือ ${p.currentStock} ชิ้น`}
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Recent Audit Logs */}
        <div className="lg:col-span-7 bg-white border border-purple-100 rounded-3xl p-5 space-y-3 shadow-xs">
          <div className="flex items-center justify-between">
            <h3 className="font-extrabold text-sm text-purple-950 flex items-center gap-2">
              <span>📜</span> ประวัติกิจกรรมล่าสุด (Audit Trail)
            </h3>
            <button
              onClick={() => onNavigateTab('reports')}
              className="text-xs text-purple-700 hover:text-purple-900 font-bold"
            >
              ดูทั้งหมด
            </button>
          </div>

          <div className="space-y-2">
            {logs.slice(0, 4).map((log) => (
              <div
                key={log.id}
                className="p-2.5 rounded-2xl bg-purple-50/40 border border-purple-100/80 flex items-start gap-2.5 text-xs"
              >
                <span className="text-base">
                  {log.type === 'sale' ? '🛒' : log.type === 'stock_in' ? '📥' : log.type === 'undo' ? '↩️' : '⚙️'}
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-purple-950 truncate">{log.action}</h4>
                    <span className="text-[10px] text-purple-600/80 font-mono">
                      {new Date(log.timestamp).toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-600 mt-0.5 line-clamp-1">{log.details}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

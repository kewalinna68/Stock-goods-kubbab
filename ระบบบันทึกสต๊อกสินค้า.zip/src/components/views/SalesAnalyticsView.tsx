import React, { useState } from 'react';
import { 
  TrendingUp, 
  DollarSign, 
  Percent, 
  Sparkles, 
  Trophy, 
  Calendar, 
  Boxes 
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip 
} from 'recharts';
import { Transaction, Product } from '../../types';
import { soundFx } from '../../utils/audio';

interface SalesAnalyticsViewProps {
  transactions: Transaction[];
  products: Product[];
}

type Period = 'today' | 'week' | 'month' | 'year' | 'all';

export const SalesAnalyticsView: React.FC<SalesAnalyticsViewProps> = ({
  transactions,
  products,
}) => {
  const [period, setPeriod] = useState<Period>('month');

  // Filter transactions
  const now = new Date();
  const filteredTx = transactions.filter((t) => {
    if (t.type !== 'SALE') return false;
    const txDate = new Date(t.timestamp);

    if (period === 'today') return txDate.toDateString() === now.toDateString();
    if (period === 'week') return txDate >= new Date(now.getTime() - 7 * 24 * 3600 * 1000);
    if (period === 'month') return txDate.getMonth() === now.getMonth() && txDate.getFullYear() === now.getFullYear();
    if (period === 'year') return txDate.getFullYear() === now.getFullYear();
    return true;
  });

  const totalSalesRevenue = filteredTx.reduce((sum, t) => sum + t.totalAmount, 0);
  const totalProfit = filteredTx.reduce((sum, t) => sum + t.totalProfit, 0);
  const marginPercentage = totalSalesRevenue > 0 ? (totalProfit / totalSalesRevenue) * 100 : 0;
  const totalInventoryValue = products.reduce((sum, p) => sum + p.currentStock * p.costPrice, 0);

  // Daily Profit & Sales Chart Data Preparation
  const thaiMonths = ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
  const dailyDataMap: { [dateKey: string]: { dateLabel: string; profit: number; revenue: number; timestamp: number } } = {};

  // Build default 7-day range
  const daysCount = period === 'today' ? 1 : period === 'week' ? 7 : 14;
  for (let i = daysCount - 1; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    d.setHours(0, 0, 0, 0);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    const dateLabel = `${d.getDate()} ${thaiMonths[d.getMonth()]}`;
    dailyDataMap[key] = { dateLabel, profit: 0, revenue: 0, timestamp: d.getTime() };
  }

  // Aggregate transaction metrics into daily keys
  filteredTx.forEach((tx) => {
    const d = new Date(tx.timestamp);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    const dateLabel = `${d.getDate()} ${thaiMonths[d.getMonth()]}`;

    if (!dailyDataMap[key]) {
      dailyDataMap[key] = { 
        dateLabel, 
        profit: 0, 
        revenue: 0, 
        timestamp: new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime() 
      };
    }
    dailyDataMap[key].profit += tx.totalProfit;
    dailyDataMap[key].revenue += tx.totalAmount;
  });

  const chartData = Object.values(dailyDataMap).sort((a, b) => a.timestamp - b.timestamp);

  // Top 5 Best Sellers calculation
  const productSalesMap: { [productId: string]: { name: string; quantity: number; revenue: number } } = {};

  filteredTx.forEach((tx) => {
    tx.items.forEach((item) => {
      if (!productSalesMap[item.productId]) {
        productSalesMap[item.productId] = { name: item.productName, quantity: 0, revenue: 0 };
      }
      productSalesMap[item.productId].quantity += item.quantity;
      productSalesMap[item.productId].revenue += item.totalPrice;
    });
  });

  const topBestSellers = Object.values(productSalesMap)
    .sort((a, b) => b.quantity - a.quantity)
    .slice(0, 5);

  const maxBestSellerQty = topBestSellers[0]?.quantity || 1;

  return (
    <div className="space-y-4 pb-16">
      {/* Header Banner */}
      <div className="bg-white border border-purple-100 rounded-3xl p-4 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 shadow-xs">
        <div>
          <h2 className="text-xl font-black text-purple-950 flex items-center gap-2">
            💸 วิเคราะห์ยอดขาย & กำไร
          </h2>
          <p className="text-xs text-purple-700/80 font-medium">
            สรุปภาพรวมยอดขายรายวัน รายสัปดาห์ รายเดือน รายปี และ 5 อันดับยี่ห้อขายดี
          </p>
        </div>

        {/* Timeframe Selector Pills */}
        <div className="flex items-center gap-1 bg-purple-50 p-1.5 rounded-2xl border border-purple-100 self-start sm:self-auto">
          {[
            { id: 'today', label: 'รายวัน' },
            { id: 'week', label: 'สัปดาห์' },
            { id: 'month', label: 'เดือน' },
            { id: 'year', label: 'ปี' },
            { id: 'all', label: 'ทั้งหมด' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => {
                soundFx.play('click');
                setPeriod(item.id as Period);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                period === item.id
                  ? 'bg-purple-600 text-white shadow-xs'
                  : 'text-purple-900 hover:bg-purple-100'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

      {/* 4 Financial Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-white border border-purple-100 rounded-3xl p-4 space-y-1 shadow-xs">
          <span className="text-xs font-bold text-purple-700">ยอดขายรวม</span>
          <div className="text-2xl font-black text-emerald-600 font-mono">
            ฿{totalSalesRevenue.toLocaleString()}
          </div>
          <p className="text-[11px] text-purple-600 font-mono">{filteredTx.length} บิลขาย</p>
        </div>

        <div className="bg-white border border-purple-100 rounded-3xl p-4 space-y-1 shadow-xs">
          <span className="text-xs font-bold text-purple-700">กำไรสุทธิ</span>
          <div className="text-2xl font-black text-purple-950 font-mono">
            ฿{totalProfit.toLocaleString()}
          </div>
          <p className="text-[11px] text-purple-600 font-medium">ราคาขาย - ราคาทุน</p>
        </div>

        <div className="bg-white border border-purple-100 rounded-3xl p-4 space-y-1 shadow-xs">
          <span className="text-xs font-bold text-purple-700">อัตรากำไรเฉลี่ย</span>
          <div className="text-2xl font-black text-amber-600 font-mono">
            {marginPercentage.toFixed(1)}%
          </div>
          <p className="text-[11px] text-purple-600 font-medium">กำไรเทียบยอดขาย</p>
        </div>

        <div className="bg-white border border-purple-100 rounded-3xl p-4 space-y-1 shadow-xs">
          <span className="text-xs font-bold text-purple-700">มูลค่าสต๊อกในร้าน</span>
          <div className="text-2xl font-black text-purple-950 font-mono">
            ฿{totalInventoryValue.toLocaleString()}
          </div>
          <p className="text-[11px] text-purple-600 font-medium">สต๊อกสินค้าคงเหลือ</p>
        </div>
      </div>

      {/* Recharts Daily Profit & Revenue Trend Chart */}
      <div className="bg-white border border-purple-100 rounded-3xl p-5 space-y-3 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="font-black text-base text-purple-950 flex items-center gap-2">
              <span>📈</span> แนวโน้มกำไรและยอดขายรายวัน (Daily Profit & Sales Trend)
            </h3>
            <p className="text-xs text-purple-700/80 font-medium mt-0.5">
              กราฟเส้นเปรียบเทียบกำไรสุทธิและยอดขายสะสมตามช่วงเวลา
            </p>
          </div>
          <div className="flex items-center gap-4 text-xs font-bold self-start sm:self-auto">
            <span className="flex items-center gap-1.5 text-emerald-700">
              <span className="w-3 h-3 rounded-full bg-emerald-500 inline-block" />
              ยอดขายรวม (บาท)
            </span>
            <span className="flex items-center gap-1.5 text-rose-600">
              <span className="w-3 h-3 rounded-full bg-rose-500 inline-block" />
              กำไรสุทธิ (บาท)
            </span>
          </div>
        </div>

        <div className="h-64 sm:h-72 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
              <defs>
                <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.35} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="colorProfit" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis 
                dataKey="dateLabel" 
                tickLine={false} 
                axisLine={false} 
                tick={{ fontSize: 11, fill: '#64748b', fontWeight: 600 }} 
              />
              <YAxis 
                tickLine={false} 
                axisLine={false} 
                tick={{ fontSize: 11, fill: '#64748b', fontWeight: 600 }}
                tickFormatter={(v) => `฿${v}`}
              />
              <Tooltip 
                content={({ active, payload, label }) => {
                  if (active && payload && payload.length) {
                    const rev = Number(payload.find(p => p.dataKey === 'revenue')?.value || 0);
                    const prof = Number(payload.find(p => p.dataKey === 'profit')?.value || 0);
                    return (
                      <div className="bg-slate-900 text-white rounded-2xl p-3 text-xs shadow-xl border border-slate-700 space-y-1">
                        <p className="font-extrabold text-amber-300 border-b border-slate-700 pb-1 mb-1">{label}</p>
                        <p className="flex justify-between gap-4 font-mono">
                          <span className="text-slate-300">ยอดขายรวม:</span>
                          <span className="font-bold text-emerald-400">฿{rev.toLocaleString()}</span>
                        </p>
                        <p className="flex justify-between gap-4 font-mono">
                          <span className="text-slate-300">กำไรสุทธิ:</span>
                          <span className="font-bold text-rose-400">฿{prof.toLocaleString()}</span>
                        </p>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Area 
                type="monotone" 
                dataKey="revenue" 
                name="ยอดขายรวม"
                stroke="#10b981" 
                strokeWidth={3}
                fillOpacity={1} 
                fill="url(#colorRevenue)" 
              />
              <Area 
                type="monotone" 
                dataKey="profit" 
                name="กำไรสุทธิ"
                stroke="#ef4444" 
                strokeWidth={3}
                fillOpacity={1} 
                fill="url(#colorProfit)" 
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Top 5 Best Sellers */}
      <div className="bg-white border border-purple-100 rounded-3xl p-5 space-y-4 shadow-xs">
        <h3 className="font-black text-base text-purple-950 flex items-center gap-2">
          <span>🏆</span> ยี่ห้อสินค้าขายดี 5 อันดับแรก (Top 5 Best Sellers)
        </h3>

        {topBestSellers.length === 0 ? (
          <div className="py-8 text-center text-purple-400 text-xs">
            ยังไม่มีข้อมูลยอดขายในช่วงเวลานี้
          </div>
        ) : (
          <div className="space-y-3">
            {topBestSellers.map((item, index) => {
              const percent = Math.round((item.quantity / maxBestSellerQty) * 100);
              return (
                <div key={index} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold font-mono ${
                        index === 0 ? 'bg-amber-400 text-slate-950' : 'bg-purple-100 text-purple-900'
                      }`}>
                        {index + 1}
                      </span>
                      <span className="font-extrabold text-purple-950">{item.name}</span>
                    </div>

                    <div className="flex items-center gap-3 font-mono text-xs">
                      <span className="text-emerald-700 font-bold">{item.quantity} ชิ้น/ลัง</span>
                      <span className="text-purple-900 font-bold">฿{item.revenue.toLocaleString()}</span>
                    </div>
                  </div>

                  <div className="w-full bg-purple-50 rounded-full h-2 overflow-hidden border border-purple-100">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-purple-500 to-pink-500 transition-all duration-500"
                      style={{ width: `${percent}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};


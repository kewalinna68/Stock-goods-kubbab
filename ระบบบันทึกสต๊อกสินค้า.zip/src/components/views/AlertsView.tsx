import React, { useState } from 'react';
import { 
  Bell, 
  AlertTriangle, 
  XCircle, 
  Clock, 
  ArrowDownLeft, 
  CheckCircle2, 
  Sparkles,
  Layers,
  Filter,
  Check,
  Calendar,
  Package,
  AlertCircle
} from 'lucide-react';
import { Product, FifoLot } from '../../types';
import { soundFx } from '../../utils/audio';

interface AlertsViewProps {
  products: Product[];
  lots: FifoLot[];
  onQuickRestock: (product: Product, quantity: number) => void;
  onOpenRestockModal: () => void;
}

type AlertFilter = 'ALL' | 'CRITICAL_7_DAYS' | 'EXPIRED' | 'LOW_STOCK';

export const AlertsView: React.FC<AlertsViewProps> = ({
  products,
  lots,
  onQuickRestock,
  onOpenRestockModal,
}) => {
  const [filterMode, setFilterMode] = useState<AlertFilter>('ALL');

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  // Process all active FIFO lots with expiration calculations
  const processedLots = lots
    .filter((lot) => lot.quantity > 0 && lot.expiryDate)
    .map((lot) => {
      const product = products.find((p) => p.id === lot.productId);
      const expDate = new Date(lot.expiryDate!);
      expDate.setHours(0, 0, 0, 0);

      const diffTime = expDate.getTime() - today.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

      return {
        lot,
        product,
        diffDays,
        isExpired: diffDays <= 0,
        isCritical7Days: diffDays > 0 && diffDays <= 7,
        isNear30Days: diffDays > 7 && diffDays <= 30,
      };
    })
    .sort((a, b) => a.diffDays - b.diffDays);

  // Filtered expiring lots
  const critical7DaysLots = processedLots.filter((item) => item.isCritical7Days || item.isExpired);
  const expiredLots = processedLots.filter((item) => item.isExpired);
  const near30DaysLots = processedLots.filter((item) => item.isNear30Days);

  // FEFO Product mapping for table
  const fefoList = products.map((p) => {
    const productLots = processedLots.filter((item) => item.lot.productId === p.id);
    const oldestLotItem = productLots[0];

    const expiryDate = oldestLotItem?.lot.expiryDate || '2027-05-10';
    const diffDays = oldestLotItem ? oldestLotItem.diffDays : 999;

    const isExpired = diffDays <= 0;
    const isCritical7Days = diffDays > 0 && diffDays <= 7;
    const isNear30Days = diffDays > 7 && diffDays <= 30;

    const isLowStock = p.currentStock > 0 && p.currentStock <= p.minAlertStock;
    const isOutOfStock = p.currentStock === 0;

    return {
      product: p,
      oldestLot: oldestLotItem?.lot,
      expiryDate,
      diffDays,
      isExpired,
      isCritical7Days,
      isNear30Days,
      isLowStock,
      isOutOfStock,
    };
  });

  const filteredProducts = fefoList.filter((item) => {
    if (filterMode === 'CRITICAL_7_DAYS') return item.isCritical7Days || item.isExpired;
    if (filterMode === 'EXPIRED') return item.isExpired;
    if (filterMode === 'LOW_STOCK') return item.isLowStock || item.isOutOfStock;
    return true;
  });

  return (
    <div className="space-y-4 pb-16">
      {/* Header Banner */}
      <div className="bg-white border border-purple-100 rounded-3xl p-4 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 shadow-xs">
        <div>
          <h2 className="text-xl font-black text-purple-950 flex items-center gap-2">
            🔔 ตรวจสอบล็อตสินค้า & วันหมดอายุ (FEFO)
          </h2>
          <p className="text-xs text-purple-700/80 font-medium">
            ดึงข้อมูลจากวันหมดอายุใน FIFO Lot แสดงแถบเตือนสินค้าที่เหลือเวลาไม่เกิน 7 วัน
          </p>
        </div>

        <button
          onClick={() => {
            soundFx.play('click');
            onOpenRestockModal();
          }}
          className="px-4 py-2.5 rounded-2xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-extrabold text-xs flex items-center justify-center gap-2 shadow-md shadow-amber-200 transition-all active:scale-95"
        >
          <Sparkles className="w-4 h-4" />
          <span>สั่งเติมสต๊อกด่วน</span>
        </button>
      </div>

      {/* Summary Expiry Badges */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* Expired Counter */}
        <div className="bg-rose-50 border border-rose-200 rounded-3xl p-3.5 flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-500 text-white flex items-center justify-center shrink-0 shadow-sm">
              <XCircle className="w-5 h-5" />
            </div>
            <div>
              <p className="text-[11px] font-bold text-rose-700 uppercase tracking-wider">หมดอายุแล้ว</p>
              <h3 className="text-lg font-black text-rose-950 font-mono">{expiredLots.length} ล็อต</h3>
            </div>
          </div>
          <span className="text-xs font-bold text-rose-600 bg-rose-100 px-2.5 py-1 rounded-xl">
            ควรเคลียร์ออก
          </span>
        </div>

        {/* Critical <= 7 Days Counter */}
        <div className="bg-amber-50 border border-amber-300 rounded-3xl p-3.5 flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500 text-slate-950 flex items-center justify-center shrink-0 shadow-sm animate-pulse">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <p className="text-[11px] font-bold text-amber-800 uppercase tracking-wider">ใกล้หมดอายุ (≤ 7 วัน)</p>
              <h3 className="text-lg font-black text-amber-950 font-mono">{critical7DaysLots.length} ล็อต</h3>
            </div>
          </div>
          <span className="text-xs font-bold text-amber-900 bg-amber-200 px-2.5 py-1 rounded-xl">
            เร่งระบาย
          </span>
        </div>

        {/* Near Expiry 30 Days Counter */}
        <div className="bg-purple-50 border border-purple-200 rounded-3xl p-3.5 flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-purple-600 text-white flex items-center justify-center shrink-0 shadow-sm">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <p className="text-[11px] font-bold text-purple-700 uppercase tracking-wider">ใกล้หมดอายุ (≤ 30 วัน)</p>
              <h3 className="text-lg font-black text-purple-950 font-mono">{near30DaysLots.length} ล็อต</h3>
            </div>
          </div>
          <span className="text-xs font-bold text-purple-700 bg-purple-100 px-2.5 py-1 rounded-xl">
            วางแผนกระจาย
          </span>
        </div>
      </div>

      {/* Critical <= 7 Days Lots Warning Section */}
      <div className="bg-white border-2 border-rose-200 rounded-3xl p-4 shadow-sm space-y-3">
        <div className="flex items-center justify-between border-b border-rose-100 pb-2.5">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-xl bg-rose-500 text-white flex items-center justify-center font-bold text-xs">
              ⚠️
            </div>
            <h3 className="font-black text-purple-950 text-base flex items-center gap-2">
              <span>รายการล็อตสินค้าที่ต้องจับตาเร่งด่วน (เหลือไม่เกิน 7 วัน)</span>
            </h3>
          </div>
          <span className="text-xs font-extrabold text-rose-600 bg-rose-50 px-3 py-1 rounded-full border border-rose-200">
            {critical7DaysLots.length} รายการ
          </span>
        </div>

        {critical7DaysLots.length === 0 ? (
          <div className="py-6 text-center text-xs font-semibold text-emerald-600 bg-emerald-50/50 rounded-2xl border border-emerald-100 flex items-center justify-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
            <span>ไม่มีล็อตสินค้าที่เหลือเวลาไม่เกิน 7 วันในขณะนี้</span>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {critical7DaysLots.map(({ lot, product, diffDays, isExpired }) => (
              <div
                key={lot.id}
                className={`p-3.5 rounded-2xl border-2 transition-all space-y-2.5 ${
                  isExpired
                    ? 'bg-rose-50/80 border-rose-300'
                    : 'bg-amber-50/80 border-amber-300 shadow-xs'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <span className="text-xl shrink-0">{product?.emoji || '📦'}</span>
                    <div>
                      <h4 className="font-black text-purple-950 text-sm leading-snug">
                        {product?.name || lot.productName}
                      </h4>
                      <p className="text-[11px] font-mono text-purple-800/80 font-bold">
                        {lot.lotNumber} • Bin: {product?.location || 'A-1'}
                      </p>
                    </div>
                  </div>

                  {/* Quantity badge */}
                  <span className="px-2.5 py-1 rounded-xl bg-white border border-purple-200 font-mono font-black text-xs text-purple-950 shrink-0">
                    คงเหลือ {lot.quantity} ลัง
                  </span>
                </div>

                {/* Expiry Warning Bar */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-xs font-extrabold">
                    <span className="flex items-center gap-1 text-slate-700">
                      <Calendar className="w-3.5 h-3.5 text-purple-600" />
                      <span>หมดอายุ: {lot.expiryDate}</span>
                    </span>

                    {isExpired ? (
                      <span className="text-rose-700 font-black bg-rose-200/80 px-2 py-0.5 rounded-lg text-[10px]">
                        🚨 หมดอายุแล้ว ({Math.abs(diffDays)} วันก่อน)
                      </span>
                    ) : (
                      <span className="text-amber-900 font-black bg-amber-200 px-2 py-0.5 rounded-lg text-[10px] animate-pulse">
                        ⚠️ เหลืออีกเพียง {diffDays} วัน!
                      </span>
                    )}
                  </div>

                  {/* Progress Bar Display */}
                  <div className="w-full h-2.5 rounded-full bg-slate-200 overflow-hidden relative">
                    <div
                      className={`h-full transition-all duration-500 ${
                        isExpired
                          ? 'bg-rose-600'
                          : 'bg-gradient-to-r from-amber-500 via-rose-500 to-rose-600 animate-pulse'
                      }`}
                      style={{
                        width: isExpired ? '100%' : `${Math.max(10, (diffDays / 7) * 100)}%`,
                      }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Filter Tabs */}
      <div className="bg-white border border-purple-100 rounded-3xl p-3 flex items-center justify-between gap-2 shadow-xs">
        <div className="flex items-center gap-2 flex-wrap">
          {[
            { id: 'ALL', label: '✨ ทั้งหมด' },
            { id: 'CRITICAL_7_DAYS', label: '⚠️ วิกฤต (≤ 7 วัน)' },
            { id: 'EXPIRED', label: '❌ หมดอายุแล้ว' },
            { id: 'LOW_STOCK', label: '🚨 สต๊อกต่ำ' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                soundFx.play('click');
                setFilterMode(tab.id as AlertFilter);
              }}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                filterMode === tab.id
                  ? 'bg-purple-600 text-white shadow-xs'
                  : 'bg-purple-50 text-purple-900 hover:bg-purple-100 border border-purple-100'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* FEFO Table */}
      <div className="bg-white border border-purple-100 rounded-3xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse whitespace-nowrap">
            <thead>
              <tr className="bg-purple-50/70 border-b border-purple-100 text-[11px] font-black text-purple-900 uppercase">
                <th className="py-3 px-4">ยี่ห้อสินค้า</th>
                <th className="py-3 px-4">📍 Bin</th>
                <th className="py-3 px-4">คงเหลือ</th>
                <th className="py-3 px-4">หมดอายุ (ล็อตเร็วสุด)</th>
                <th className="py-3 px-4 text-center">แถบเตือนเวลา (FEFO)</th>
                <th className="py-3 px-4 text-center">จัดการ</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-purple-100/60 text-xs font-medium whitespace-nowrap">
              {filteredProducts.map(({ product: p, expiryDate, diffDays, isExpired, isCritical7Days, isNear30Days, isLowStock, isOutOfStock }) => (
                <tr key={p.id} className="hover:bg-purple-50/40 transition-colors">
                  {/* Name + Emoji */}
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-2 whitespace-nowrap">
                      <span className="text-base shrink-0">{p.emoji || '🥤'}</span>
                      <span className="font-extrabold text-purple-950 text-sm">{p.name}</span>
                    </div>
                  </td>

                  {/* Location Bin */}
                  <td className="py-3.5 px-4 font-mono text-xs font-bold text-purple-900">
                    <span className="px-2 py-0.5 rounded-lg bg-purple-50 border border-purple-200">
                      {p.location}
                    </span>
                  </td>

                  {/* Current Stock */}
                  <td className="py-3.5 px-4 font-mono font-bold text-purple-950">
                    {p.currentStock} ลัง
                  </td>

                  {/* Expiry Date */}
                  <td className={`py-3.5 px-4 font-mono font-bold ${
                    isExpired
                      ? 'text-rose-700'
                      : isCritical7Days
                      ? 'text-amber-700'
                      : 'text-slate-700'
                  }`}>
                    {expiryDate}
                  </td>

                  {/* Warning Status Bar */}
                  <td className="py-3.5 px-4 text-center">
                    {isExpired && (
                      <span className="px-3 py-1 rounded-full bg-rose-100 text-rose-800 border border-rose-300 font-bold text-[10px] inline-flex items-center gap-1 shadow-2xs">
                        ❌ หมดอายุแล้ว
                      </span>
                    )}
                    {!isExpired && isCritical7Days && (
                      <span className="px-3 py-1 rounded-full bg-amber-100 text-amber-900 border border-amber-400 font-black text-[10px] inline-flex items-center gap-1 animate-pulse shadow-2xs">
                        ⚠️ เหลือไม่เกิน {diffDays} วัน!
                      </span>
                    )}
                    {!isExpired && !isCritical7Days && isNear30Days && (
                      <span className="px-3 py-1 rounded-full bg-purple-100 text-purple-800 border border-purple-300 font-bold text-[10px] inline-flex items-center gap-1">
                        ⏳ เหลือ {diffDays} วัน
                      </span>
                    )}
                    {!isExpired && !isCritical7Days && !isNear30Days && (
                      <span className="px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold text-[10px] inline-flex items-center gap-1">
                        🟢 ปกติ (&gt;30 วัน)
                      </span>
                    )}
                  </td>

                  {/* Action Button */}
                  <td className="py-3.5 px-4 text-center">
                    <button
                      onClick={() => {
                        soundFx.play('click');
                        const qtyToRestock = Math.max(10, p.targetStock - p.currentStock);
                        onQuickRestock(p, qtyToRestock);
                      }}
                      className="px-2.5 py-1 rounded-xl bg-purple-100 hover:bg-purple-200 text-purple-900 font-bold text-[10px] transition-all"
                    >
                      + เติม {Math.max(10, p.targetStock - p.currentStock)}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};


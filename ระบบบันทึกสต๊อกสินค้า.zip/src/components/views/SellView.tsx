import React, { useState, useEffect } from 'react';
import { 
  ShoppingCart, 
  Search, 
  QrCode, 
  Plus, 
  Minus, 
  Trash2, 
  CheckCircle2, 
  RotateCcw, 
  Sparkles,
  Zap,
  Star,
  Receipt,
  X
} from 'lucide-react';
import { Product, FifoLot, TransactionItem, UndoState } from '../../types';
import { soundFx } from '../../utils/audio';
import { Html5QrcodeScanner } from 'html5-qrcode';

interface SellViewProps {
  products: Product[];
  lots: FifoLot[];
  onCompleteSale: (items: TransactionItem[], note?: string) => void;
  undoState: UndoState | null;
  onUndo: () => void;
}

export const SellView: React.FC<SellViewProps> = ({
  products,
  lots,
  onCompleteSale,
  undoState,
  onUndo,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [cart, setCart] = useState<{ product: Product; quantity: number }[]>([]);
  const [note, setNote] = useState('');
  const [completedTxReceipt, setCompletedTxReceipt] = useState<any | null>(null);

  // Scanner modal state
  const [isScannerOpen, setIsScannerOpen] = useState(false);

  // Filter products
  const filteredProducts = products.filter((p) => {
    return (
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.location.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  const frequentProducts = products.filter((p) => p.frequentUse);

  // Add item to cart
  const addToCart = (product: Product, qty: number = 1) => {
    if (product.currentStock <= 0) {
      soundFx.speakLowStockAlert(product.name, 0);
      alert(`สินค้า "${product.name}" หมดสต๊อกแล้ว`);
      return;
    }

    // Voice & sound alert if scanned/selected item stock is low or below threshold
    if (product.currentStock <= product.minAlertStock) {
      soundFx.speakLowStockAlert(product.name, product.currentStock);
    } else {
      soundFx.play('click');
    }

    setCart((prevCart) => {
      const existing = prevCart.find((item) => item.product.id === product.id);
      if (existing) {
        const nextQty = existing.quantity + qty;
        if (nextQty > product.currentStock) {
          alert(`คงเหลือในสต๊อกเพียง ${product.currentStock} ชิ้น`);
          return prevCart;
        }
        return prevCart.map((item) =>
          item.product.id === product.id ? { ...item, quantity: nextQty } : item
        );
      }
      return [...prevCart, { product, quantity: qty }];
    });
  };

  const adjustCartQty = (productId: string, amount: number) => {
    soundFx.play('click');
    setCart((prevCart) =>
      prevCart
        .map((item) => {
          if (item.product.id === productId) {
            const nextQty = item.quantity + amount;
            if (nextQty > item.product.currentStock) {
              alert(`คงเหลือในสต๊อกเพียง ${item.product.currentStock} ชิ้น`);
              return item;
            }
            return { ...item, quantity: nextQty };
          }
          return item;
        })
        .filter((item) => item.quantity > 0)
    );
  };

  const removeFromCart = (productId: string) => {
    soundFx.play('click');
    setCart((prev) => prev.filter((i) => i.product.id !== productId));
  };

  // Calculate totals
  const totalAmount = cart.reduce((sum, item) => sum + item.product.salePrice * item.quantity, 0);
  const totalCost = cart.reduce((sum, item) => sum + item.product.costPrice * item.quantity, 0);
  const totalProfit = totalAmount - totalCost;

  // Checkout Handler
  const handleCheckout = () => {
    if (cart.length === 0) return;

    soundFx.play('sale');

    const txItems: TransactionItem[] = cart.map((item) => ({
      productId: item.product.id,
      productName: item.product.name,
      quantity: item.quantity,
      unitPrice: item.product.salePrice,
      unitCost: item.product.costPrice,
      totalPrice: item.product.salePrice * item.quantity,
      totalCost: item.product.costPrice * item.quantity,
    }));

    const tx = onCompleteSale(txItems, note);

    setCompletedTxReceipt({
      txId: tx ? tx.id : 'TX-' + Date.now().toString().slice(-4),
      items: cart,
      totalAmount,
      totalProfit,
      timestamp: new Date().toLocaleString('th-TH'),
    });

    setCart([]);
    setNote('');
  };

  // Camera QR Scanner Initialization
  useEffect(() => {
    if (!isScannerOpen) return;

    let scanner: Html5QrcodeScanner | null = null;

    try {
      scanner = new Html5QrcodeScanner(
        'reader-modal',
        { fps: 10, qrbox: { width: 220, height: 220 } },
        false
      );

      scanner.render(
        (decodedText) => {
          soundFx.play('click');
          const matchedProduct = products.find(
            (p) => p.code.toLowerCase() === decodedText.toLowerCase() || p.id === decodedText
          );

          if (matchedProduct) {
            addToCart(matchedProduct, 1);
            setIsScannerOpen(false);
          } else {
            alert(`ไม่พบสินค้าตรงกับโค้ด "${decodedText}"`);
          }
        },
        () => {}
      );
    } catch {
      // Camera permissions or unsupported browser
    }

    return () => {
      if (scanner) {
        scanner.clear().catch(() => {});
      }
    };
  }, [isScannerOpen]);

  return (
    <div className="space-y-4 pb-16">
      {/* Header Banner */}
      <div className="bg-white border border-purple-100 rounded-3xl p-4 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 shadow-xs">
        <div>
          <h2 className="text-xl font-black text-purple-950 flex items-center gap-2">
            🛍️ ขายสินค้า & สแกนบาร์โค้ด
          </h2>
          <p className="text-xs text-purple-700/80 font-medium">
            สแกนบาร์โค้ด หรือแตะรายการสินค้าหยิบบ่อย เพื่อบันทึกการขายและตัดสต๊อก FIFO
          </p>
        </div>

        <button
          onClick={() => setIsScannerOpen(true)}
          className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-purple-600 to-pink-600 text-white font-extrabold text-xs flex items-center justify-center gap-2 shadow-md shadow-purple-200 transition-all active:scale-95"
        >
          <QrCode className="w-4 h-4" />
          <span>เปิดกล้องสแกนบาร์โค้ด</span>
        </button>
      </div>

      {/* Main Grid: POS Products (Left) + Cart (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Side: Search & Product Catalog (8 cols) */}
        <div className="lg:col-span-7 space-y-3">
          {/* Search Bar */}
          <div className="relative">
            <Search className="w-4 h-4 text-purple-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="สแกน หรือพิมพ์ค้นหายี่ห้อสินค้า..."
              className="w-full bg-white border border-purple-100 rounded-2xl pl-10 pr-4 py-3 text-xs text-purple-950 font-bold focus:outline-none focus:ring-2 focus:ring-purple-400 shadow-xs"
            />
          </div>

          {/* Frequent Products Shelf */}
          {frequentProducts.length > 0 && (
            <div className="bg-white border border-purple-100 rounded-3xl p-3.5 space-y-2 shadow-xs">
              <span className="text-xs font-black text-purple-950 flex items-center gap-1.5">
                <span>⭐</span> สินค้าหยิบบ่อย (แตะทีเดียวเข้าตะกร้า)
              </span>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {frequentProducts.slice(0, 8).map((p) => {
                  const isOut = p.currentStock === 0;
                  return (
                    <button
                      key={p.id}
                      onClick={() => addToCart(p, 1)}
                      disabled={isOut}
                      className={`p-2.5 rounded-2xl border text-left transition-all active:scale-95 flex flex-col justify-between ${
                        isOut
                          ? 'bg-slate-50 border-slate-200 text-slate-400 opacity-60'
                          : 'bg-purple-50/50 hover:bg-purple-100/80 border-purple-100 text-purple-950'
                      }`}
                    >
                      <div className="flex items-center gap-1.5">
                        <span className="text-base">{p.emoji || '🥤'}</span>
                        <h4 className="font-bold text-xs truncate">{p.name}</h4>
                      </div>
                      <div className="mt-2 flex items-center justify-between font-mono text-[11px] font-bold">
                        <span className="text-purple-900">฿{p.salePrice}</span>
                        <span className={isOut ? 'text-rose-600' : 'text-emerald-700'}>
                          {isOut ? 'หมด' : `${p.currentStock}`}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Main Product Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 max-h-[480px] overflow-y-auto pr-1">
            {filteredProducts.map((p) => {
              const isOut = p.currentStock === 0;
              return (
                <button
                  key={p.id}
                  onClick={() => addToCart(p, 1)}
                  disabled={isOut}
                  className={`p-3 rounded-2xl border text-left transition-all active:scale-95 flex flex-col justify-between bg-white ${
                    isOut
                      ? 'border-slate-200 text-slate-400 opacity-60 cursor-not-allowed'
                      : 'border-purple-100 hover:border-purple-300 text-purple-950 shadow-2xs hover:shadow-md'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xl">{p.emoji || '🥤'}</span>
                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded-md bg-purple-50 text-purple-800 font-bold border border-purple-100">
                        {p.location}
                      </span>
                    </div>
                    <h4 className="font-extrabold text-xs line-clamp-1">{p.name}</h4>
                  </div>

                  <div className="mt-3 pt-2 border-t border-purple-100 flex items-center justify-between font-mono text-[11px]">
                    <span className="font-black text-purple-950 text-xs">฿{p.salePrice}</span>
                    <span className={`font-bold ${isOut ? 'text-rose-600' : 'text-emerald-700'}`}>
                      {isOut ? 'หมด' : `${p.currentStock} ชิ้น`}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Side: Cart Summary & Checkout (5 cols) */}
        <div className="lg:col-span-5 bg-white border border-purple-100 rounded-3xl p-5 space-y-4 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-purple-100 pb-3">
              <h3 className="font-black text-base text-purple-950 flex items-center gap-2">
                <span>🛒</span> ตะกร้าสินค้าขาย
              </h3>
              <span className="text-xs font-mono font-bold text-purple-600 bg-purple-50 px-2.5 py-1 rounded-full border border-purple-100">
                {cart.reduce((s, i) => s + i.quantity, 0)} ชิ้น
              </span>
            </div>

            {/* Cart Items List */}
            <div className="space-y-2 mt-3 max-h-[300px] overflow-y-auto pr-1">
              {cart.length === 0 ? (
                <div className="py-12 text-center text-purple-400 text-xs font-bold space-y-1">
                  <ShoppingCart className="w-8 h-8 mx-auto text-purple-200" />
                  <p>ยังไม่มีรายการสินค้าในตะกร้า</p>
                  <p className="text-[10px] text-purple-300">เลือกสินค้าจากรายการด้านซ้ายเพื่อสแกนขาย</p>
                </div>
              ) : (
                cart.map(({ product, quantity }) => (
                  <div
                    key={product.id}
                    className="p-2.5 rounded-2xl bg-purple-50/50 border border-purple-100 flex items-center justify-between text-xs"
                  >
                    <div className="min-w-0">
                      <h4 className="font-bold text-purple-950 truncate">{product.name}</h4>
                      <span className="text-[10px] font-mono text-purple-600">
                        ฿{product.salePrice} x {quantity} = ฿{product.salePrice * quantity}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        onClick={() => adjustCartQty(product.id, -1)}
                        className="w-6 h-6 rounded-lg bg-white text-purple-900 border border-purple-200 font-bold flex items-center justify-center"
                      >
                        -
                      </button>
                      <span className="font-mono font-bold text-purple-950 w-6 text-center">
                        {quantity}
                      </span>
                      <button
                        onClick={() => adjustCartQty(product.id, 1)}
                        className="w-6 h-6 rounded-lg bg-white text-purple-900 border border-purple-200 font-bold flex items-center justify-center"
                      >
                        +
                      </button>
                      <button
                        onClick={() => removeFromCart(product.id)}
                        className="p-1 text-rose-500 hover:text-rose-700 ml-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Checkout Totals & Submit */}
          <div className="space-y-3 pt-3 border-t border-purple-100">
            <div className="space-y-1 font-mono text-xs">
              <div className="flex items-center justify-between text-purple-700">
                <span>ยอดรวมราคาสินค้า</span>
                <span className="font-black text-base text-purple-950">฿{totalAmount.toLocaleString()}</span>
              </div>
              <div className="flex items-center justify-between text-emerald-700 text-[11px]">
                <span>กำไรคาดการณ์</span>
                <span className="font-bold">+฿{totalProfit.toLocaleString()}</span>
              </div>
            </div>

            <button
              onClick={handleCheckout}
              disabled={cart.length === 0}
              className={`w-full py-3.5 rounded-2xl font-black text-sm flex items-center justify-center gap-2 shadow-md transition-all active:scale-98 ${
                cart.length === 0
                  ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                  : 'bg-pink-600 hover:bg-pink-500 text-white shadow-pink-200'
              }`}
            >
              <CheckCircle2 className="w-5 h-5" />
              <span>กดบันทึกการขาย (฿{totalAmount.toLocaleString()})</span>
            </button>
          </div>
        </div>
      </div>

      {/* Camera Barcode Scanner Modal */}
      {isScannerOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3">
          <div className="bg-white border border-purple-100 rounded-3xl max-w-sm w-full p-5 space-y-4 shadow-xl">
            <div className="flex items-center justify-between">
              <h3 className="font-black text-sm text-purple-950 flex items-center gap-2">
                <QrCode className="w-4 h-4 text-purple-600" /> สแกนบาร์โค้ดด้วยกล้อง
              </h3>
              <button
                onClick={() => setIsScannerOpen(false)}
                className="p-1 rounded-xl text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div id="reader-modal" className="overflow-hidden rounded-2xl border border-purple-100" />

            <button
              onClick={() => setIsScannerOpen(false)}
              className="w-full py-2.5 rounded-xl bg-purple-100 text-purple-900 font-bold text-xs"
            >
              ปิดกล้อง
            </button>
          </div>
        </div>
      )}

      {/* Receipt Modal */}
      {completedTxReceipt && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3">
          <div className="bg-white border border-purple-100 rounded-3xl max-w-xs w-full p-5 text-center space-y-4 shadow-xl">
            <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>

            <div>
              <h3 className="font-black text-base text-purple-950">บันทึกการขายสำเร็จ!</h3>
              <p className="text-xs font-mono text-purple-600">รหัสบิล #{completedTxReceipt.txId}</p>
            </div>

            <div className="bg-purple-50/60 border border-purple-100 rounded-2xl p-3 text-xs space-y-1 text-left font-mono">
              {completedTxReceipt.items.map((i: any) => (
                <div key={i.product.id} className="flex justify-between">
                  <span>{i.product.name} (x{i.quantity})</span>
                  <span className="font-bold">฿{i.product.salePrice * i.quantity}</span>
                </div>
              ))}
              <div className="pt-2 border-t border-purple-200 flex justify-between font-extrabold text-purple-950">
                <span>ยอดรวม</span>
                <span className="text-pink-600 font-black">฿{completedTxReceipt.totalAmount}</span>
              </div>
            </div>

            <button
              onClick={() => setCompletedTxReceipt(null)}
              className="w-full py-2.5 rounded-2xl bg-purple-600 text-white font-bold text-xs"
            >
              เสร็จสิ้น
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

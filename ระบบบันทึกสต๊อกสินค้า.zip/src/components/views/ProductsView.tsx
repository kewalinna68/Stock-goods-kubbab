import React, { useState } from 'react';
import { 
  Boxes, 
  Search, 
  Plus, 
  Edit3, 
  Trash2, 
  QrCode, 
  Tag, 
  Star, 
  MapPin, 
  Filter,
  Check,
  X,
  Sparkles,
  Printer
} from 'lucide-react';
import { Product } from '../../types';
import { soundFx } from '../../utils/audio';
import QRCode from 'qrcode';

interface ProductsViewProps {
  products: Product[];
  onAddProduct: (product: Omit<Product, 'createdAt' | 'updatedAt'>) => void;
  onEditProduct: (product: Product) => void;
  onDeleteProduct: (id: string) => void;
  onToggleFrequent: (id: string) => void;
}

export const ProductsView: React.FC<ProductsViewProps> = ({
  products,
  onAddProduct,
  onEditProduct,
  onDeleteProduct,
  onToggleFrequent,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [mainGroup, setMainGroup] = useState<'ALL' | 'FOOD' | 'HOUSEHOLD'>('ALL');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  // Classification for food vs household goods
  const foodCategories = ['น้ำอัดลม', 'น้ำผลไม้', 'นมวัว', 'นมถั่วเหลือง', 'ชา-กาแฟ', 'เครื่องดื่ม', 'น้ำดื่ม', 'ขนมอบกรอบ', 'อาหารแห้ง', 'เครื่องปรุงรส'];

  // Modals
  const [isAddEditModalOpen, setIsAddEditModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  const [qrModalProduct, setQrModalProduct] = useState<Product | null>(null);
  const [qrDataUrl, setQrDataUrl] = useState<string | null>(null);

  const [priceTagProduct, setPriceTagProduct] = useState<Product | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    code: '',
    name: '',
    emoji: '🥤',
    category: 'น้ำอัดลม',
    costPrice: 0,
    salePrice: 0,
    currentStock: 0,
    minAlertStock: 10,
    targetStock: 30,
    location: '📍 A-01',
    frequentUse: false,
  });

  // Extract categories according to active group filter
  const allSubCategories: string[] = Array.from(new Set(products.map((p) => p.category)));
  const availableCategories = ['ALL', ...allSubCategories.filter((cat) => {
    if (mainGroup === 'FOOD') return foodCategories.includes(cat);
    if (mainGroup === 'HOUSEHOLD') return !foodCategories.includes(cat);
    return true;
  })];

  // Filter products
  const filteredProducts = products.filter((p) => {
    const isFood = foodCategories.includes(p.category);
    let matchGroup = true;
    if (mainGroup === 'FOOD') matchGroup = isFood;
    if (mainGroup === 'HOUSEHOLD') matchGroup = !isFood;

    const matchCat = selectedCategory === 'ALL' || p.category === selectedCategory;
    const matchSearch =
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.location.toLowerCase().includes(searchTerm.toLowerCase());
    return matchGroup && matchCat && matchSearch;
  });

  const handleOpenAdd = () => {
    soundFx.play('click');
    setEditingProduct(null);
    setFormData({
      code: 'SKU-' + Math.floor(100 + Math.random() * 900),
      name: '',
      emoji: '🥤',
      category: 'น้ำอัดลม',
      costPrice: 10,
      salePrice: 15,
      currentStock: 20,
      minAlertStock: 10,
      targetStock: 40,
      location: '📍 A-01',
      frequentUse: false,
    });
    setIsAddEditModalOpen(true);
  };

  const handleOpenEdit = (p: Product) => {
    soundFx.play('click');
    setEditingProduct(p);
    setFormData({
      code: p.code,
      name: p.name,
      emoji: p.emoji || '🥤',
      category: p.category,
      costPrice: p.costPrice,
      salePrice: p.salePrice,
      currentStock: p.currentStock,
      minAlertStock: p.minAlertStock,
      targetStock: p.targetStock,
      location: p.location,
      frequentUse: !!p.frequentUse,
    });
    setIsAddEditModalOpen(true);
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    soundFx.play('stock_in');

    if (editingProduct) {
      onEditProduct({
        ...editingProduct,
        ...formData,
        updatedAt: new Date().toISOString(),
      });
    } else {
      onAddProduct({
        id: 'P-' + Date.now().toString().slice(-5),
        ...formData,
      });
    }

    setIsAddEditModalOpen(false);
  };

  // QR Generator
  const handleShowQr = async (p: Product) => {
    soundFx.play('click');
    setQrModalProduct(p);
    try {
      const url = await QRCode.toDataURL(p.code || p.id, { width: 300, margin: 2 });
      setQrDataUrl(url);
    } catch {
      setQrDataUrl(null);
    }
  };

  // Category Badge Colors
  const getCategoryBadgeClass = (category: string) => {
    switch (category) {
      case 'น้ำอัดลม':
        return 'bg-pink-100 text-pink-700 border-pink-200';
      case 'น้ำผลไม้':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'นมวัว':
        return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'นมถั่วเหลือง':
        return 'bg-amber-50 text-amber-900 border-amber-200';
      case 'ชา-กาแฟ':
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      default:
        return 'bg-purple-100 text-purple-800 border-purple-200';
    }
  };

  return (
    <div className="space-y-4 pb-16">
      {/* Header Banner */}
      <div className="bg-white border border-purple-100 rounded-3xl p-4 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 shadow-xs">
        <div>
          <h2 className="text-xl font-black text-purple-950 flex items-center gap-2">
            🧃 จัดการข้อมูลสต๊อก
          </h2>
          <p className="text-xs text-purple-700/80 font-medium">
            จัดการรายการสินค้า ราคาขาย ราคาทุน ตำแหน่งจัดเก็บ Bin และสร้าง QR/ป้ายราคา
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white font-extrabold text-xs flex items-center justify-center gap-2 shadow-md shadow-pink-200 transition-all active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>เพิ่มยี่ห้อสินค้าใหม่</span>
        </button>
      </div>

      {/* Search & Category Filter Toolbar */}
      <div className="bg-white border border-purple-100 rounded-3xl p-4 space-y-3 shadow-xs">
        {/* Top Row: Search Input & Macro Group Selector */}
        <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3">
          {/* Search Input */}
          <div className="relative w-full lg:w-72 shrink-0">
            <Search className="w-4 h-4 text-purple-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="ค้นหายี่ห้อ, SKU, ตำแหน่ง..."
              className="w-full bg-purple-50/50 border border-purple-100 rounded-2xl pl-9 pr-3 py-2.5 text-xs font-medium text-purple-950 focus:outline-none focus:ring-2 focus:ring-purple-400"
            />
          </div>

          {/* Macro Group Filter Tabs (ของกิน vs ของใช้ vs ทั้งหมด) */}
          <div className="flex items-center gap-1.5 p-1 bg-purple-50/80 rounded-2xl border border-purple-100 self-start lg:self-auto overflow-x-auto max-w-full">
            <button
              onClick={() => {
                soundFx.play('click');
                setMainGroup('ALL');
                setSelectedCategory('ALL');
              }}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black whitespace-nowrap transition-all flex items-center gap-1.5 ${
                mainGroup === 'ALL'
                  ? 'bg-purple-600 text-white shadow-xs'
                  : 'text-purple-700 hover:bg-purple-100'
              }`}
            >
              <span>✨ ทั้งหมด</span>
              <span className={`px-1.5 py-0.5 rounded-md text-[10px] ${mainGroup === 'ALL' ? 'bg-purple-700 text-white' : 'bg-purple-200/70 text-purple-900'}`}>
                {products.length}
              </span>
            </button>

            <button
              onClick={() => {
                soundFx.play('click');
                setMainGroup('FOOD');
                setSelectedCategory('ALL');
              }}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black whitespace-nowrap transition-all flex items-center gap-1.5 ${
                mainGroup === 'FOOD'
                  ? 'bg-amber-500 text-white shadow-xs'
                  : 'text-amber-900 hover:bg-amber-100/70'
              }`}
            >
              <span>🍱 ของกิน / เครื่องดื่ม</span>
              <span className={`px-1.5 py-0.5 rounded-md text-[10px] ${mainGroup === 'FOOD' ? 'bg-amber-600 text-white' : 'bg-amber-200/70 text-amber-900'}`}>
                {products.filter((p) => foodCategories.includes(p.category)).length}
              </span>
            </button>

            <button
              onClick={() => {
                soundFx.play('click');
                setMainGroup('HOUSEHOLD');
                setSelectedCategory('ALL');
              }}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black whitespace-nowrap transition-all flex items-center gap-1.5 ${
                mainGroup === 'HOUSEHOLD'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-blue-900 hover:bg-blue-100/70'
              }`}
            >
              <span>🧼 ของใช้</span>
              <span className={`px-1.5 py-0.5 rounded-md text-[10px] ${mainGroup === 'HOUSEHOLD' ? 'bg-blue-700 text-white' : 'bg-blue-200/70 text-blue-900'}`}>
                {products.filter((p) => !foodCategories.includes(p.category)).length}
              </span>
            </button>
          </div>
        </div>

        {/* Bottom Row: Subcategory Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pt-1 border-t border-purple-50">
          <span className="text-[11px] font-extrabold text-purple-400 shrink-0 mr-1 flex items-center gap-1">
            <Filter className="w-3 h-3" /> หมวดหมู่ย่อย:
          </span>
          {availableCategories.map((cat) => (
            <button
              key={cat}
              onClick={() => {
                soundFx.play('click');
                setSelectedCategory(cat);
              }}
              className={`px-2.5 py-1 rounded-xl text-xs font-extrabold whitespace-nowrap transition-all ${
                selectedCategory === cat
                  ? 'bg-purple-900 text-white shadow-2xs'
                  : 'bg-purple-50 text-purple-700 border border-purple-100/80 hover:bg-purple-100'
              }`}
            >
              {cat === 'ALL' ? 'ทุกหมวดหมู่ย่อย' : cat}
            </button>
          ))}
        </div>
      </div>

      {/* Stocky-style Table List */}
      <div className="bg-white border border-purple-100 rounded-3xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse whitespace-nowrap">
            <thead>
              <tr className="bg-purple-50/70 border-b border-purple-100 text-[11px] font-black text-purple-900 uppercase">
                <th className="py-3 px-4">ยี่ห้อสินค้า</th>
                <th className="py-3 px-4">หมวดหมู่</th>
                <th className="py-3 px-4">📍 Bin</th>
                <th className="py-3 px-4">คงเหลือ</th>
                <th className="py-3 px-4">ขั้นต่ำ</th>
                <th className="py-3 px-4">ราคาขาย</th>
                <th className="py-3 px-4 text-center">📱 QR</th>
                <th className="py-3 px-4 text-center">⚙️ จัดการ</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-purple-100/60 text-xs font-medium whitespace-nowrap">
              {filteredProducts.map((p) => {
                const isLow = p.currentStock > 0 && p.currentStock <= p.minAlertStock;
                const isOut = p.currentStock === 0;

                return (
                  <tr key={p.id} className="hover:bg-purple-50/40 transition-colors">
                    {/* Name + Emoji */}
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2 whitespace-nowrap">
                        <span className="text-base shrink-0">{p.emoji || '🥤'}</span>
                        <span className="font-extrabold text-purple-950 text-sm">{p.name}</span>
                        {p.frequentUse && (
                          <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500 shrink-0" title="หยิบบ่อย" />
                        )}
                      </div>
                    </td>

                    {/* Category Tag */}
                    <td className="py-3 px-4">
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold border ${getCategoryBadgeClass(p.category)}`}>
                        {p.category}
                      </span>
                    </td>

                    {/* Location Bin */}
                    <td className="py-3 px-4 font-mono text-xs font-bold text-purple-900">
                      <span className="px-2 py-0.5 rounded-lg bg-purple-50 border border-purple-200">
                        {p.location}
                      </span>
                    </td>

                    {/* Current Stock */}
                    <td className="py-3 px-4 font-mono font-bold">
                      <span className={`px-2.5 py-0.5 rounded-full text-xs ${
                        isOut
                          ? 'bg-rose-100 text-rose-700 font-extrabold'
                          : isLow
                          ? 'bg-amber-100 text-amber-800'
                          : 'text-purple-950'
                      }`}>
                        {p.currentStock} ลัง/ชิ้น
                      </span>
                    </td>

                    {/* Min Alert Level */}
                    <td className="py-3 px-4 font-mono text-slate-400">
                      {p.minAlertStock}
                    </td>

                    {/* Sale Price */}
                    <td className="py-3 px-4 font-mono font-bold text-purple-900">
                      ฿{p.salePrice}
                    </td>

                    {/* QR Code Action */}
                    <td className="py-3 px-4 text-center">
                      <button
                        onClick={() => handleShowQr(p)}
                        className="px-2.5 py-1 rounded-lg bg-purple-100 hover:bg-purple-200 text-purple-800 text-[11px] font-bold inline-flex items-center gap-1.5"
                      >
                        <QrCode className="w-3.5 h-3.5" />
                        <span>QR</span>
                      </button>
                    </td>

                    {/* Edit / Delete / Tags Actions */}
                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => setPriceTagProduct(p)}
                          className="p-1.5 rounded-lg bg-purple-50 hover:bg-purple-100 text-purple-700"
                          title="ดูป้ายราคา"
                        >
                          <Tag className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleOpenEdit(p)}
                          className="p-1.5 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700"
                          title="แก้ไข"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => {
                            if (confirm(`คุณต้องการลบ "${p.name}" หรือไม่?`)) {
                              onDeleteProduct(p.id);
                            }
                          }}
                          className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600"
                          title="ลบ"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Product Modal */}
      {isAddEditModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3">
          <div className="bg-white border border-purple-100 rounded-3xl max-w-md w-full p-5 space-y-4 shadow-xl animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-purple-100 pb-3">
              <h3 className="font-extrabold text-base text-purple-950 flex items-center gap-2">
                <span>🥤</span> {editingProduct ? 'แก้ไขยี่ห้อสินค้า' : 'เพิ่มยี่ห้อสินค้าใหม่'}
              </h3>
              <button
                onClick={() => setIsAddEditModalOpen(false)}
                className="p-1 rounded-xl text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="space-y-3 text-xs">
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">อิโมจิ</label>
                  <input
                    type="text"
                    value={formData.emoji}
                    onChange={(e) => setFormData({ ...formData, emoji: e.target.value })}
                    className="w-full bg-purple-50/50 border border-purple-200 rounded-xl px-3 py-2 text-center text-lg focus:outline-none"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block font-bold text-slate-700 mb-1">รหัส SKU / บาร์โค้ด</label>
                  <input
                    type="text"
                    value={formData.code}
                    onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                    required
                    className="w-full bg-purple-50/50 border border-purple-200 rounded-xl px-3 py-2 font-mono font-bold text-purple-950 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">ชื่อยี่ห้อสินค้า *</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                  placeholder="เช่น Coke Original, Pepsi Max"
                  className="w-full bg-purple-50/50 border border-purple-200 rounded-xl px-3 py-2 font-bold text-purple-950 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">หมวดหมู่</label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    className="w-full bg-purple-50/50 border border-purple-200 rounded-xl px-3 py-2 font-bold text-purple-950 focus:outline-none"
                  >
                    <option value="น้ำอัดลม">น้ำอัดลม</option>
                    <option value="น้ำผลไม้">น้ำผลไม้</option>
                    <option value="นมวัว">นมวัว</option>
                    <option value="นมถั่วเหลือง">นมถั่วเหลือง</option>
                    <option value="ชา-กาแฟ">ชา-กาแฟ</option>
                    <option value="อาหารแห้ง">อาหารแห้ง</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">📍 Bin ตำแหน่ง</label>
                  <input
                    type="text"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    required
                    placeholder="📍 A-01"
                    className="w-full bg-purple-50/50 border border-purple-200 rounded-xl px-3 py-2 font-bold text-purple-950 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">ราคาทุน (บาท)</label>
                  <input
                    type="number"
                    value={formData.costPrice}
                    onChange={(e) => setFormData({ ...formData, costPrice: Number(e.target.value) })}
                    required
                    className="w-full bg-purple-50/50 border border-purple-200 rounded-xl px-3 py-2 font-mono font-bold focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">ราคาขาย (บาท)</label>
                  <input
                    type="number"
                    value={formData.salePrice}
                    onChange={(e) => setFormData({ ...formData, salePrice: Number(e.target.value) })}
                    required
                    className="w-full bg-purple-50/50 border border-purple-200 rounded-xl px-3 py-2 font-mono font-bold text-purple-900 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">สต๊อกตั้งต้น</label>
                  <input
                    type="number"
                    value={formData.currentStock}
                    onChange={(e) => setFormData({ ...formData, currentStock: Number(e.target.value) })}
                    required
                    className="w-full bg-purple-50/50 border border-purple-200 rounded-xl px-3 py-2 font-mono font-bold focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">ขั้นต่ำ (Min)</label>
                  <input
                    type="number"
                    value={formData.minAlertStock}
                    onChange={(e) => setFormData({ ...formData, minAlertStock: Number(e.target.value) })}
                    required
                    className="w-full bg-purple-50/50 border border-purple-200 rounded-xl px-3 py-2 font-mono font-bold focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">เป้าหมาย</label>
                  <input
                    type="number"
                    value={formData.targetStock}
                    onChange={(e) => setFormData({ ...formData, targetStock: Number(e.target.value) })}
                    required
                    className="w-full bg-purple-50/50 border border-purple-200 rounded-xl px-3 py-2 font-mono font-bold focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="frequentUse"
                  checked={formData.frequentUse}
                  onChange={(e) => setFormData({ ...formData, frequentUse: e.target.checked })}
                  className="w-4 h-4 text-purple-600 rounded-md"
                />
                <label htmlFor="frequentUse" className="font-bold text-purple-900">
                  ⭐ ตั้งเป็นสินค้าหยิบบ่อย (แสดงบนแผงขายด่วน)
                </label>
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-2xl bg-purple-600 hover:bg-purple-700 text-white font-black text-sm shadow-md mt-2"
              >
                บันทึกข้อมูลสินค้า
              </button>
            </form>
          </div>
        </div>
      )}

      {/* QR Code Modal */}
      {qrModalProduct && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3">
          <div className="bg-white border border-purple-100 rounded-3xl max-w-xs w-full p-5 text-center space-y-4 shadow-xl">
            <h3 className="font-extrabold text-sm text-purple-950 flex items-center justify-center gap-1">
              <span>{qrModalProduct.emoji || '🥤'}</span> {qrModalProduct.name}
            </h3>

            {qrDataUrl && (
              <img src={qrDataUrl} alt="QR Code" className="w-48 h-48 mx-auto rounded-2xl border border-purple-100 p-2 shadow-xs" />
            )}

            <p className="font-mono text-xs font-bold text-purple-700">{qrModalProduct.code}</p>

            <button
              onClick={() => setQrModalProduct(null)}
              className="w-full py-2 rounded-xl bg-purple-100 text-purple-900 font-bold text-xs"
            >
              ปิด
            </button>
          </div>
        </div>
      )}

      {/* Price Tag Preview Modal */}
      {priceTagProduct && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3">
          <div className="bg-white border-2 border-purple-200 rounded-3xl max-w-xs w-full p-5 text-center space-y-3 shadow-xl">
            <div className="bg-purple-50 border border-purple-200 rounded-2xl p-4 text-left space-y-2">
              <span className="text-3xl block text-center mb-1">{priceTagProduct.emoji || '🥤'}</span>
              <h4 className="font-black text-base text-purple-950 text-center">{priceTagProduct.name}</h4>
              <div className="flex items-center justify-between font-mono text-xs text-purple-800 pt-2 border-t border-purple-200">
                <span>SKU: {priceTagProduct.code}</span>
                <span className="font-bold">{priceTagProduct.location}</span>
              </div>
              <div className="text-center pt-2">
                <span className="text-[10px] text-purple-600 block uppercase font-bold">ราคาขาย</span>
                <span className="text-3xl font-black text-pink-600 font-mono">฿{priceTagProduct.salePrice}</span>
              </div>
            </div>

            <button
              onClick={() => setPriceTagProduct(null)}
              className="w-full py-2 rounded-xl bg-purple-600 text-white font-bold text-xs"
            >
              ตกลง
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

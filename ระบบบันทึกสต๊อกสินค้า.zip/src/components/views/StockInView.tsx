import React, { useState } from 'react';
import { 
  ArrowDownLeft, 
  Plus, 
  Minus, 
  Check, 
  Sparkles, 
  PackageCheck, 
  Calendar,
  Layers,
  ChevronDown,
  Clock,
  History,
  Tag,
  MapPin,
  TrendingUp,
  FileText
} from 'lucide-react';
import { Product, FifoLot } from '../../types';
import { soundFx } from '../../utils/audio';

interface StockInViewProps {
  products: Product[];
  lots?: FifoLot[];
  onStockIn: (
    product: Product,
    quantity: number,
    costPrice: number,
    expiryDate?: string,
    lotNumber?: string
  ) => void;
}

export const StockInView: React.FC<StockInViewProps> = ({
  products,
  lots = [],
  onStockIn,
}) => {
  const [selectedProductId, setSelectedProductId] = useState<string>(products[0]?.id || '');
  const [quantity, setQuantity] = useState<number>(10);
  const [poReference, setPoReference] = useState<string>('PO-' + new Date().getFullYear() + '-001');
  const [expiryDays, setExpiryDays] = useState<number | null>(365);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const selectedProduct = products.find((p) => p.id === selectedProductId) || products[0];

  const handleSelectProduct = (id: string) => {
    soundFx.play('click');
    setSelectedProductId(id);
  };

  const adjustQty = (amount: number) => {
    soundFx.play('click');
    setQuantity((prev) => Math.max(1, prev + amount));
  };

  const calculateExpiryDate = (days: number | null): string | undefined => {
    if (days === null) return undefined;
    const d = new Date();
    d.setDate(d.getDate() + days);
    return d.toISOString().split('T')[0];
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProduct) return;

    soundFx.play('stock_in');

    const expDate = calculateExpiryDate(expiryDays);
    const lotNum = 'LOT-' + new Date().toISOString().slice(2, 10).replace(/-/g, '') + '-' + Math.floor(10 + Math.random() * 90);

    const prevStock = selectedProduct.currentStock;
    const newStock = prevStock + quantity;

    onStockIn(selectedProduct, quantity, selectedProduct.costPrice, expDate, lotNum);

    setSuccessMsg(`อัปเดตสำเร็จ! "${selectedProduct.name}" สต๊อกเพิ่มจาก ${prevStock} ➔ ${newStock} ชิ้น/ลัง (+${quantity})`);

    setQuantity(10);

    setTimeout(() => {
      setSuccessMsg(null);
    }, 5000);
  };

  const totalBatchCost = selectedProduct ? selectedProduct.costPrice * quantity : 0;
  const projectedStock = selectedProduct ? selectedProduct.currentStock + quantity : 0;

  return (
    <div className="space-y-5 pb-16 max-w-3xl mx-auto">
      {/* Header Banner */}
      <div className="bg-white border border-purple-100 rounded-3xl p-5 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 text-white flex items-center justify-center font-bold text-xl shadow-md shadow-purple-200 shrink-0">
            📥
          </div>
          <div>
            <h2 className="text-lg font-black text-purple-950">
              บันทึกรับสินค้าเข้าคลัง (Stock In)
            </h2>
            <p className="text-xs text-purple-700/80 font-medium mt-0.5">
              เลือกรายการสินค้า ระบุจำนวนที่รับเข้า ระบบจะคำนวณต้นทุนและอัปเดตสต๊อกทันที
            </p>
          </div>
        </div>
      </div>

      {/* Main Form Card with Section Breakdowns */}
      <div className="bg-white border border-purple-100 rounded-3xl p-6 shadow-xs space-y-6">
        {/* Success Banner */}
        {successMsg && (
          <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-2xl flex items-center gap-3 text-xs font-extrabold shadow-xs animate-fadeIn">
            <PackageCheck className="w-5 h-5 text-emerald-600 shrink-0" />
            <span className="leading-relaxed">{successMsg}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* STEP 1: Select Product & Information */}
          <div className="space-y-3">
            <div className="flex items-center gap-2 border-b border-purple-100 pb-2">
              <span className="w-6 h-6 rounded-full bg-purple-600 text-white text-xs font-black flex items-center justify-center shrink-0">1</span>
              <h3 className="font-extrabold text-sm text-purple-950">เลือกยี่ห้อสินค้า</h3>
            </div>

            <div className="space-y-2">
              <div className="relative">
                <select
                  value={selectedProductId}
                  onChange={(e) => handleSelectProduct(e.target.value)}
                  className="w-full bg-purple-50/50 border border-purple-200 rounded-2xl px-4 py-3 text-sm font-extrabold text-purple-950 appearance-none focus:outline-none focus:ring-2 focus:ring-purple-400 cursor-pointer pr-10"
                >
                  {products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.emoji || '🥤'} {p.name} — [{p.category}] (คงเหลือ: {p.currentStock})
                    </option>
                  ))}
                </select>
                <ChevronDown className="w-5 h-5 text-purple-500 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>

              {/* Product Info Highlights Grid */}
              {selectedProduct && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                  <div className="bg-purple-50/60 p-2.5 rounded-2xl border border-purple-100/80">
                    <span className="text-[10px] text-purple-600 font-bold block">หมวดหมู่</span>
                    <span className="text-xs font-black text-purple-950 truncate block mt-0.5">{selectedProduct.category}</span>
                  </div>

                  <div className="bg-purple-50/60 p-2.5 rounded-2xl border border-purple-100/80">
                    <span className="text-[10px] text-purple-600 font-bold block">พิกัดจัดเก็บ (Bin)</span>
                    <span className="text-xs font-black text-purple-950 truncate block mt-0.5">{selectedProduct.location}</span>
                  </div>

                  <div className="bg-purple-50/60 p-2.5 rounded-2xl border border-purple-100/80">
                    <span className="text-[10px] text-purple-600 font-bold block">ราคาทุนต่อหน่วย</span>
                    <span className="text-xs font-black text-purple-950 font-mono block mt-0.5">฿{selectedProduct.costPrice.toLocaleString()}</span>
                  </div>

                  <div className="bg-emerald-50/80 p-2.5 rounded-2xl border border-emerald-100">
                    <span className="text-[10px] text-emerald-700 font-bold block">สต๊อกปัจจุบัน</span>
                    <span className="text-sm font-black text-emerald-700 font-mono block mt-0.5">{selectedProduct.currentStock} ชิ้น</span>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* STEP 2: Quantity & Batch Details */}
          <div className="space-y-3">
            <div className="flex items-center gap-2 border-b border-purple-100 pb-2">
              <span className="w-6 h-6 rounded-full bg-purple-600 text-white text-xs font-black flex items-center justify-center shrink-0">2</span>
              <h3 className="font-extrabold text-sm text-purple-950">ระบุจำนวนที่รับเข้า</h3>
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-center gap-2 sm:gap-3 bg-purple-50/40 p-4 rounded-2xl border border-purple-100">
                <button
                  type="button"
                  onClick={() => adjustQty(-10)}
                  className="px-3 py-2 rounded-xl bg-white hover:bg-purple-100 text-purple-900 font-extrabold text-xs border border-purple-200 active:scale-95 transition-all"
                >
                  -10
                </button>
                <button
                  type="button"
                  onClick={() => adjustQty(-1)}
                  className="w-10 h-10 rounded-xl bg-white hover:bg-purple-100 text-purple-900 font-extrabold flex items-center justify-center border border-purple-200 active:scale-95 transition-all shrink-0"
                >
                  <Minus className="w-4 h-4" />
                </button>

                <div className="text-center px-4">
                  <span className="text-3xl font-black text-purple-950 font-mono">
                    {quantity}
                  </span>
                  <span className="text-[10px] text-purple-600 block font-bold">ลัง / ชิ้น</span>
                </div>

                <button
                  type="button"
                  onClick={() => adjustQty(1)}
                  className="w-10 h-10 rounded-xl bg-white hover:bg-purple-100 text-purple-900 font-extrabold flex items-center justify-center border border-purple-200 active:scale-95 transition-all shrink-0"
                >
                  <Plus className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => adjustQty(10)}
                  className="px-3 py-2 rounded-xl bg-white hover:bg-purple-100 text-purple-900 font-extrabold text-xs border border-purple-200 active:scale-95 transition-all"
                >
                  +10
                </button>
              </div>

              {/* Quick Select Quantity Pills */}
              <div className="flex items-center justify-center gap-2 pt-1 flex-wrap">
                <span className="text-xs font-bold text-purple-600/80 mr-1">เลือกจำนวนด่วน:</span>
                {[5, 10, 20, 50, 100].map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => {
                      soundFx.play('click');
                      setQuantity(preset);
                    }}
                    className={`px-3 py-1 rounded-xl text-xs font-extrabold font-mono transition-all ${
                      quantity === preset
                        ? 'bg-purple-600 text-white shadow-xs'
                        : 'bg-purple-50 text-purple-900 border border-purple-100 hover:bg-purple-100'
                    }`}
                  >
                    +{preset}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* STEP 3: Reference & Summary Breakdown */}
          <div className="space-y-3">
            <div className="flex items-center gap-2 border-b border-purple-100 pb-2">
              <span className="w-6 h-6 rounded-full bg-purple-600 text-white text-xs font-black flex items-center justify-center shrink-0">3</span>
              <h3 className="font-extrabold text-sm text-purple-950">สรุปรายละเอียดการรับเข้า</h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="block text-xs font-bold text-purple-900">
                  เลขอ้างอิง PO / บิล
                </label>
                <input
                  type="text"
                  value={poReference}
                  onChange={(e) => setPoReference(e.target.value)}
                  className="w-full bg-purple-50/50 border border-purple-200 rounded-xl px-3.5 py-2 text-xs font-mono font-bold text-purple-950 focus:outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-bold text-purple-900">
                  กำหนดวันหมดอายุ
                </label>
                <select
                  value={expiryDays === null ? 'none' : expiryDays}
                  onChange={(e) => setExpiryDays(e.target.value === 'none' ? null : Number(e.target.value))}
                  className="w-full bg-purple-50/50 border border-purple-200 rounded-xl px-3.5 py-2 text-xs font-bold text-purple-950 focus:outline-none"
                >
                  <option value={180}>6 เดือน (ประมาณ {calculateExpiryDate(180)})</option>
                  <option value={365}>1 ปี (ประมาณ {calculateExpiryDate(365)})</option>
                  <option value={730}>2 ปี (ประมาณ {calculateExpiryDate(730)})</option>
                  <option value="none">ไม่อยู่ในข่ายหมดอายุ</option>
                </select>
              </div>
            </div>

            {/* Live Summary Calculation Box */}
            <div className="bg-gradient-to-r from-purple-950 to-indigo-900 text-white p-4 rounded-2xl space-y-2 shadow-sm">
              <div className="text-xs font-bold text-purple-200 flex items-center justify-between border-b border-purple-700/60 pb-2">
                <span>สรุปยอดรับเข้าคลังครั้งนี้</span>
                <span className="font-mono text-amber-300 font-extrabold">พิกัด {selectedProduct?.location}</span>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-1 text-xs">
                <div>
                  <span className="text-purple-300 block text-[11px]">สต๊อกเดิม ➔ สต๊อกใหม่</span>
                  <span className="font-black font-mono text-base text-emerald-300">
                    {selectedProduct?.currentStock} ➔ {projectedStock} ชิ้น
                  </span>
                </div>

                <div className="text-right">
                  <span className="text-purple-300 block text-[11px]">มูลค่าต้นทุนรวม</span>
                  <span className="font-black font-mono text-base text-amber-300">
                    ฿{totalBatchCost.toLocaleString()}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full py-4 rounded-2xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-black text-sm shadow-lg shadow-indigo-200 flex items-center justify-center gap-2 transition-all active:scale-98"
          >
            <Check className="w-5 h-5" />
            <span>ยืนยันการรับเข้าคลัง (+{quantity} ลัง)</span>
          </button>
        </form>
      </div>

      {/* Recent Received Stock Lots Table */}
      {lots.length > 0 && (
        <div className="bg-white border border-purple-100 rounded-3xl p-5 shadow-xs space-y-3">
          <div className="flex items-center justify-between border-b border-purple-100 pb-3">
            <h3 className="font-black text-sm text-purple-950 flex items-center gap-2">
              <History className="w-4 h-4 text-purple-600" />
              <span>ประวัติล็อตรับเข้าคลังล่าสุด</span>
            </h3>
            <span className="text-[11px] font-bold text-purple-600 font-mono">
              รวม {lots.length} ล็อต
            </span>
          </div>

          <div className="divide-y divide-purple-50 overflow-hidden">
            {lots.slice(0, 6).map((lot) => (
              <div key={lot.id} className="py-2.5 flex items-center justify-between text-xs hover:bg-purple-50/50 px-2 rounded-xl transition-all">
                <div className="space-y-0.5">
                  <div className="font-extrabold text-purple-950 flex items-center gap-2">
                    <span>{lot.productName}</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-purple-100 text-purple-700 font-bold">
                      {lot.lotNumber}
                    </span>
                  </div>
                  <div className="text-[11px] text-purple-600/80 flex items-center gap-2">
                    <Clock className="w-3 h-3 text-purple-400" />
                    <span>วันที่รับเข้า: {lot.receivedDate}</span>
                    {lot.expiryDate && <span className="text-amber-700 font-semibold">• หมดอายุ: {lot.expiryDate}</span>}
                  </div>
                </div>
                <div className="text-right font-mono shrink-0">
                  <span className="font-black text-emerald-600 text-sm block">+{lot.quantity} ชิ้น</span>
                  <span className="text-[10px] text-purple-500 font-sans">ต้นทุน ฿{lot.costPrice}/ชิ้น</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
